// GymStockPro — Service Worker
//
// Estrategia: red primero, cache como respaldo.
// El cache existe solo para que la app ABRA sin conexion; los datos
// siempre vienen del servidor. Las llamadas a /api/ nunca se cachean:
// hacerlo congelaria el inventario en una version vieja.

const CACHE = 'gymstockpro-v5';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/db.js',
  './js/sync.js',
  './js/utils.js',
  './js/products.js',
  './js/sales.js',
  './js/consignment.js',
  './js/suppliers.js',
  './js/reports.js',
  './js/cashflows.js',
  './js/app.js',
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(ASSETS))
      .catch(() => {})
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // La API y todo lo que no sea GET pasan directo a la red, sin tocar el cache.
  if (e.request.method !== 'GET' || url.pathname.startsWith('/api/')) return;

  // Recursos de otros origenes (fuentes): cache si ya lo tenemos, si no red.
  if (url.origin !== self.location.origin) {
    e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)));
    return;
  }

  // Red primero: asi los cambios de la app llegan al celular de inmediato.
  e.respondWith(
    fetch(e.request)
      .then(res => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy)).catch(() => {});
        }
        return res;
      })
      .catch(() => caches.match(e.request)
        .then(hit => hit || caches.match('./index.html')))
  );
});
