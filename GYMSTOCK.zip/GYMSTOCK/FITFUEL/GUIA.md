# GymStockPro — uso en celular

## Qué cambió y por qué

Antes los datos vivían **dentro del navegador** de la PC (IndexedDB). Eso hacía
imposible usar la app desde el celular: cada dispositivo, y cada dirección
distinta, tenía su propia base vacía.

Ahora los datos viven en el **servidor**, en un archivo de tu computadora:

```
data/gymstock.json          ← toda tu información
data/backups/               ← respaldos automáticos rotativos
data/config.json            ← PIN (cifrado) y sesiones
```

La PC y el celular leen y escriben ahí, así que ven siempre lo mismo.

---

## Arranque

**No tienes que hacer nada.** Al encender la computadora arrancan solos:

- el **servicio `cloudflared`**, que publica la app en internet;
- la **tarea `GymStockServidor`**, que mantiene `server.py` en el puerto 3000.

Ambos corren como `SYSTEM` y se disparan **al arrancar la maquina**, no al
iniciar sesion: aunque se vaya la luz y la PC vuelva sola, el celular sigue
funcionando sin que nadie toque nada.

La direccion del celular es **fija**:

```
https://app.fitfuelgt.com
```

En esta computadora sigue siendo `http://localhost:3000`.

Para arrancarlo a mano y *ver* lo que pasa, `INICIAR.bat`. Si el servidor y el
tunel ya estan arriba no levanta copias duplicadas: solo te recuerda la
direccion.

Si solo quieres usarla en la PC, sin exponerla a internet:
`start-server.vbs` (arranca sin ventana) o `python iniciar.py --local`.

Registros: `data/servidor.log` (servidor) y `data/cloudflared.log` (tunel).

---

## Primera vez: orden importante

1. **Arranca** con `INICIAR.bat` (o deja que arranque solo).
2. **Abre `http://localhost:3000` en la PC.** Aquí ocurre la migración: la app
   detecta tus datos en el navegador y los sube al servidor. Verás el aviso
   *"Migración lista: N registros ahora viven en el servidor"*.
   → Confirma que tus productos y ventas aparecen bien.
3. **Define tu PIN**: Configuración → *Acceso desde el celular* → escribe un PIN
   → Guardar.
   Sin PIN, el acceso por el túnel está **bloqueado** (a propósito).
4. **En el celular**, abre la dirección `trycloudflare.com` que salió en la
   ventana, escribe el PIN y listo.
5. Opcional: en el celular, *Compartir → Añadir a pantalla de inicio*. Queda
   como una app con su ícono.

La migración corre **una sola vez**: si el servidor ya tiene datos, se niega a
sobreescribirlos.

---

## Sobre la dirección del túnel

`app.fitfuelgt.com` es un **túnel con nombre** sobre tu dominio de Cloudflare:
la dirección es permanente. Antes esto era un *quick tunnel* gratuito cuya URL
cambiaba en cada reinicio, que es justo lo que rompía el acceso desde el
celular cada mañana.

El túnel se llama `gymstock` en tu cuenta de Cloudflare. El DNS es un CNAME de
`app.fitfuelgt.com` hacia el túnel; el resto de la zona (la landing en Pages,
el correo) no se tocó.

Nada de esto expone puertos en tu router: `cloudflared` abre la conexión hacia
afuera, y Cloudflare la publica. El PIN sigue siendo lo que protege la entrada.

---

## Respaldos

- **Automáticos**: antes de cada escritura (como mucho uno cada 5 minutos) se
  guarda una copia en `data/backups/`. Se conservan las últimas 60.
- **Manual**: Configuración → Datos → *Exportar datos* descarga un JSON.
- **Directo del navegador**: `http://localhost:3000/respaldo-navegador.html`
  lee la base original del navegador sin pasar por el servidor. Es la red de
  seguridad por si algo saliera mal con la migración.

Las escrituras son atómicas (se escribe a un archivo temporal y se reemplaza),
así que un corte de luz no deja el archivo a medias. Si el archivo llegara a
estar ilegible, el servidor **se niega a arrancar** en lugar de empezar de cero,
y aparta una copia en `data/backups/ILEGIBLE-*.json`.

---

## Detalles de funcionamiento

**Sincronización.** Cada dispositivo consulta cambios cada 6 segundos y
redibuja la pantalla si hubo movimiento en otro. No es instantáneo, pero para
una tienda es más que suficiente.

**Ventas simultáneas.** El descuento de inventario se resuelve en el servidor,
no en el navegador. Si vendes la misma proteína desde la PC y el celular al
mismo tiempo, el stock baja 2, no 1.

**Sin conexión.** Si se cae la conexión con el servidor, la app queda en
**solo lectura** con un aviso amarillo, mostrando lo último que había. No
guarda cambios en cola a propósito: aceptar ventas a ciegas en dos dispositivos
desconectados descuadraría el inventario.

**Seguridad.** El PIN solo se pide a quien entra por el túnel; en la PC nunca.
Se guarda cifrado (PBKDF2, 120 000 iteraciones), tolera 8 intentos fallidos cada
15 minutos, y solo puede cambiarse desde la computadora — nadie remoto puede
apoderarse de la app. La sesión dura 30 días por dispositivo.

---

## Problemas comunes

**La app abre vacía en la PC.**
No migró. Abre `http://localhost:3000/respaldo-navegador.html`: si ahí ves tus
registros, descarga el JSON e impórtalo en Configuración → Datos → Importar.
Si sale vacío, tus datos están en otro navegador o en otra dirección; abre esa
misma página desde donde sí usabas la app.

**El celular dice "Sin conexión".**
La dirección ya no cambia, así que casi siempre es que la PC está apagada,
suspendida o sin internet. Si está encendida, comprueba las dos piezas desde
una terminal: `sc query cloudflared` debe decir `RUNNING`, y
`netstat -ano | findstr :3000` debe mostrar algo escuchando. Los registros
están en `data/cloudflared.log` y `data/servidor.log`.

**El celular muestra una versión vieja.**
Cierra la pestaña y vuelve a abrirla. El service worker ahora pide siempre la
versión del servidor primero, así que basta con recargar.

**"Demasiados intentos. Espera 15 minutos."**
Ocho PIN incorrectos. Espera, o cambia el PIN desde la PC (eso reinicia el
contador y cierra las sesiones abiertas).

---

## Archivos

| Archivo | Qué hace |
|---|---|
| Servicio `cloudflared` | Publica `app.fitfuelgt.com` desde el arranque |
| Tarea `GymStockServidor` | Mantiene `server.py` vivo desde el arranque |
| `servidor-persistente.bat` | Lo que ejecuta esa tarea: reintenta si el servidor se cae |
| `instalar-servicios.bat` | Instala ambos (una sola vez, como administrador) |
| `desinstalar-servicios.bat` | Los quita y deja todo como antes |
| `INICIAR.bat` | Arranque manual, con ventana, para ver qué pasa |
| `iniciar.py` | Lanzador; `--local` para no exponer a internet |
| `server.py` | Servidor: archivos, API de datos, PIN, respaldos |
| `js/db.js` | Capa de datos del cliente (habla con el servidor) |
| `js/sync.js` | PIN, sincronización y estado de conexión |
| `respaldo-navegador.html` | Exporta la base original del navegador |
| `bin/cloudflared.exe` | Túnel de Cloudflare (portátil, sin instalación) |
| `data/` | Tus datos y respaldos — **no borrar** |

Cambiar el PIN desde la terminal, si hiciera falta:

```
python server.py --set-pin 1234
```
