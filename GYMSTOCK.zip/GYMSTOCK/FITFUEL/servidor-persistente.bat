@echo off
REM Mantiene server.py corriendo indefinidamente. Lo ejecuta la tarea
REM "GymStockServidor" al ARRANCAR LA MAQUINA, como SYSTEM, sin que nadie
REM tenga que iniciar sesion en Windows.
REM
REM El tunel NO se levanta aqui: de eso se encarga el servicio "cloudflared".
REM Para arrancar todo a mano y verlo, usa INICIAR.bat.
cd /d "%~dp0"
if not exist data mkdir data

set PY=C:\Users\Admin\AppData\Local\Programs\Python\Python312\python.exe
if not exist "%PY%" set PY=python

:loop
echo [%date% %time%] Iniciando servidor... >> data\servidor.log
"%PY%" server.py --port 3000 >> data\servidor.log 2>&1
echo [%date% %time%] El servidor se detuvo (codigo %errorlevel%). Reintento en 10s... >> data\servidor.log
REM 'timeout' necesita una consola de verdad y la tarea corre sin ella;
REM 'ping' es la espera que si funciona en sesion 0.
ping -n 11 127.0.0.1 >nul
goto loop
