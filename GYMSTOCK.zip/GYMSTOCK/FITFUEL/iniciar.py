#!/usr/bin/env python3
"""
Arranca GymStockPro y el tunel de Cloudflare.

Normalmente NO hace falta ejecutarlo: el servidor y el tunel arrancan solos
al encender la maquina (tarea "GymStockServidor" + servicio "cloudflared").
Esto es para arrancarlo a mano y ver que pasa.

  python iniciar.py            servidor + tunel
  python iniciar.py --local    solo servidor (sin acceso desde fuera)

Si el servidor o el tunel ya estan arriba, se reutilizan en vez de arrancar
una segunda copia que chocaria con la primera.

Cierra esta ventana (o Ctrl+C) para apagar lo que haya arrancado aqui.
"""

import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT = os.path.dirname(os.path.abspath(__file__))
SERVER = os.path.join(ROOT, "server.py")
PORT = 3000

# Tunel con nombre: la direccion es fija y sobrevive a los reinicios. Si el
# config.yml no existe se vuelve al quick tunnel de antes, con su URL que
# cambia en cada arranque.
TUNNEL_NAME = "gymstock"
HOSTNAME = "app.fitfuelgt.com"
CONFIG_YML = os.path.join(os.path.expanduser("~"), ".cloudflared", "config.yml")

URL_RE = re.compile(r"https://[-a-z0-9]+\.trycloudflare\.com")

procs = []


def find_cloudflared():
    # Primero el binario que vive junto al proyecto (no requiere instalacion).
    local = os.path.join(ROOT, "bin", "cloudflared.exe")
    if os.path.isfile(local):
        return local
    found = shutil.which("cloudflared")
    if found:
        return found
    candidates = [
        os.path.expandvars(r"%ProgramFiles%\cloudflared\cloudflared.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\cloudflared\cloudflared.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\cloudflared.exe"),
        os.path.expandvars(r"%USERPROFILE%\scoop\shims\cloudflared.exe"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def shutdown(*_):
    print("\nApagando…")
    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    time.sleep(0.6)
    for p in procs:
        try:
            if p.poll() is None:
                p.kill()
        except Exception:
            pass
    sys.exit(0)


def puerto_ocupado(port):
    # Si la tarea del sistema ya levanto el servidor, arrancar otro aqui solo
    # daria "address already in use" y dos procesos peleando por el JSON.
    import socket
    with socket.socket() as sock:
        sock.settimeout(0.8)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def servicio_tunel_activo():
    # Mismo motivo: si el servicio "cloudflared" ya publica el tunel, abrir
    # una segunda copia no aporta nada.
    try:
        out = subprocess.run(["sc", "query", "cloudflared"],
                             capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return False
    return "RUNNING" in (out or "").upper()


def anunciar(url, fija):
    # Deja la direccion tambien en un archivo, por si cierras la ventana.
    try:
        with open(os.path.join(ROOT, "direccion-celular.txt"), "w",
                  encoding="utf-8") as fh:
            fh.write(url + "\n")
    except Exception:
        pass
    print("\n" + "=" * 58, flush=True)
    print("  LISTO — abre esta direccion en tu celular:", flush=True)
    print("\n      " + url + "\n", flush=True)
    print("  Te pedira el PIN la primera vez (se recuerda 30 dias).", flush=True)
    print("  En esta computadora sigue siendo http://localhost:%d" % PORT, flush=True)
    if fija:
        print("\n  Esta direccion es FIJA: no cambia aunque reinicies.", flush=True)
        print("  Guardala en la pantalla de inicio del celular.", flush=True)
    else:
        print("\n  IMPORTANTE: esta direccion cambia cada vez que", flush=True)
        print("  reinicias. Deja esta ventana abierta mientras uses la app.", flush=True)
    print("=" * 58 + "\n", flush=True)


def main():
    local_only = "--local" in sys.argv
    signal.signal(signal.SIGINT, shutdown)

    # ── Servidor ────────────────────────────────────────────────
    server = None
    if puerto_ocupado(PORT):
        print("Ya hay un servidor en el puerto %d (la tarea GymStockServidor)."
              " Lo reutilizo." % PORT)
    else:
        server = subprocess.Popen([sys.executable, SERVER, "--port", str(PORT)])
        procs.append(server)
        time.sleep(1.8)
        if server.poll() is not None:
            print("El servidor no pudo arrancar. Revisa el mensaje de arriba.")
            return 1

    if local_only:
        print("\nSolo local: http://localhost:%d\n"
              "Cierra esta ventana para apagar." % PORT)
        if server is not None:
            server.wait()
        return 0

    # ── Tunel ───────────────────────────────────────────────────
    exe = find_cloudflared()
    if not exe:
        print("\n" + "!" * 58)
        print(" No encontre 'cloudflared'.")
        print(" Instalalo con:  winget install --id Cloudflare.cloudflared")
        print(" Mientras tanto la app funciona en http://localhost:%d" % PORT)
        print("!" * 58 + "\n")
        if server is not None:
            server.wait()
        return 1

    con_nombre = os.path.isfile(CONFIG_YML)

    # El tunel con nombre ya lo publica el servicio: no hay nada que levantar,
    # solo recordarte la direccion.
    if con_nombre and servicio_tunel_activo():
        anunciar("https://" + HOSTNAME, fija=True)
        print("El servicio 'cloudflared' ya publica el tunel; no arranco otro.",
              flush=True)
        if server is not None:
            server.wait()
        return 0

    log_path = os.path.join(ROOT, "data", "cloudflared.log")
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    # Empezar con el log limpio: si se acumula, la direccion de una corrida
    # anterior se confunde con la actual y se anuncia una URL ya muerta.
    try:
        os.remove(log_path)
    except OSError:
        pass

    if con_nombre:
        # Direccion fija: no hay URL que pescar, se conoce de antemano.
        tunnel = subprocess.Popen(
            [exe, "--config", CONFIG_YML, "--no-autoupdate",
             "--logfile", log_path, "tunnel", "run", TUNNEL_NAME],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1)
        procs.append(tunnel)
        # Vaciar la tuberia: si nadie lee, cloudflared acaba bloqueandose.
        threading.Thread(target=lambda: [None for _ in tunnel.stdout],
                         daemon=True).start()
        print("Levantando el tunel… (tarda unos segundos)", flush=True)
        time.sleep(6)
        anunciar("https://" + HOSTNAME, fija=True)
    else:
        # Sin config.yml: quick tunnel de siempre, con la URL que hay que
        # pescar de la salida de cloudflared.
        tunnel = subprocess.Popen(
            [exe, "tunnel", "--url", "http://127.0.0.1:%d" % PORT,
             "--no-autoupdate", "--logfile", log_path],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1)
        procs.append(tunnel)

        found = {}

        def watch_stream():
            for line in tunnel.stdout:
                match = URL_RE.search(line)
                if match and not found.get("url"):
                    found["url"] = match.group(0)
                    anunciar(found["url"], fija=False)

        def watch_logfile():
            # cloudflared escribe la URL en su log; es mas fiable que stdout.
            deadline = time.time() + 90
            while time.time() < deadline and not found.get("url"):
                time.sleep(1)
                try:
                    with open(log_path, encoding="utf-8",
                              errors="replace") as fh:
                        matches = URL_RE.findall(fh.read())
                except OSError:
                    continue
                # La ultima coincidencia es siempre la de esta corrida.
                if matches and not found.get("url"):
                    found["url"] = matches[-1]
                    anunciar(found["url"], fija=False)
            if not found.get("url"):
                print("\nNo se pudo obtener la direccion del tunel.", flush=True)
                print("Revisa %s" % log_path, flush=True)

        threading.Thread(target=watch_stream, daemon=True).start()
        threading.Thread(target=watch_logfile, daemon=True).start()
        print("Levantando el tunel… (tarda unos segundos)", flush=True)

    try:
        while True:
            if server is not None and server.poll() is not None:
                print("El servidor se detuvo.")
                break
            if tunnel.poll() is not None:
                print("El tunel se detuvo.")
                break
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    shutdown()


if __name__ == "__main__":
    sys.exit(main() or 0)
