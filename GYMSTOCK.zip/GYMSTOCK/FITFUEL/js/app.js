// GymStockPro — App Controller, Dashboard, Settings, Router
window.App = (() => {

  // 'mobile' marca las 4 secciones que van en la barra inferior del celular;
  // el resto vive en la hoja "Más".
  const ROUTES = {
    dashboard: { label: 'Dashboard', short: 'Inicio', icon: '📊', mobile: true, fn: showDashboard },
    productos: { label: 'Productos', short: 'Productos', icon: '📦', mobile: true, fn: () => ProductsModule.render() },
    ventas: { label: 'Ventas', short: 'Ventas', icon: '🛒', mobile: true, fn: () => SalesModule.render() },
    consignaciones: { label: 'Consignaciones', short: 'Consig.', icon: '🤝', fn: () => ConsignmentModule.render() },
    proveedores: { label: 'Proveedores', short: 'Proveed.', icon: '🏭', fn: () => SuppliersModule.render() },
    reportes: { label: 'Reportes', short: 'Reportes', icon: '📈', mobile: true, fn: () => ReportsModule.render() },
    flujo: { label: 'Flujo de Caja', short: 'Caja', icon: '💵', fn: () => CashflowsModule.render() },
    configuracion: { label: 'Configuración', short: 'Ajustes', icon: '⚙️', fn: showSettings },
  };

  let currentRoute = 'dashboard';

  const navigate = (route) => {
    currentRoute = route;
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.route === route);
    });
    // En el celular, "Más" queda marcado si la seccion actual vive ahi dentro.
    const more = document.getElementById('nav-more-btn');
    if (more) more.classList.toggle('active', !ROUTES[route]?.mobile);
    closeMoreSheet();
    const fn = ROUTES[route]?.fn;
    if (fn) fn();
    document.getElementById('main-content')?.scrollTo?.(0, 0);
    window.scrollTo(0, 0);
    localStorage.setItem('gymsp_route', route);
  };

  const openMoreSheet = () => document.getElementById('more-sheet')?.classList.add('open');
  const closeMoreSheet = () => document.getElementById('more-sheet')?.classList.remove('open');

  // ── Dashboard ─────────────────────────────────────────────────
  async function showDashboard() {
    const [products, sales, consignments, movements, purchases, cashflows] = await Promise.all([
      GymDB.getAll('products'),
      GymDB.getAll('sales'),
      GymDB.getAll('consignments'),
      GymDB.getAll('movements'),
      GymDB.getAll('purchases'),
      GymDB.getAll('cashflows')
    ]);

    const now = new Date();
    const regularSales = sales.filter(s => s.type !== 'return');
    const returnSales  = sales.filter(s => s.type === 'return');

    const todaySales = regularSales.filter(s => new Date(s.date).toDateString() === now.toDateString());
    const todayReturns = returnSales.filter(s => new Date(s.date).toDateString() === now.toDateString());
    const todayRevenue = todaySales.reduce((s, v) => s + v.total, 0)
      - todayReturns.reduce((s, r) => s + Math.abs(r.total || 0), 0);
    const lowStock = products.filter(p => (p.stock || 0) <= (p.minStock || 5) && p.stock > 0);
    const outStock = products.filter(p => (p.stock || 0) <= 0);
    const pendingCS = consignments.filter(c => c.items?.some(i => i.status === 'pendiente'));

    // Financial calculations (net of returns)
    const totalRevenue = regularSales.reduce((s, v) => s + (v.total || 0), 0)
      - returnSales.reduce((s, r) => s + Math.abs(r.total || 0), 0);
    const totalPurchaseCost = products.reduce((s, p) => s + (p.stock || 0) * (p.buyPrice || 0), 0);
    const costOf = (arr) => arr.reduce((sum, sale) =>
      sum + (sale.items || []).reduce((s, item) => {
        const prod = products.find(p => p.id === item.productId);
        return s + (prod?.buyPrice || 0) * item.quantity;
      }, 0), 0);
    const salesCost = costOf(regularSales) - costOf(returnSales);
    const netProfit = totalRevenue - salesCost;
    const profitMargin = totalRevenue ? (netProfit / totalRevenue * 100) : 0;

    // Cash flow from other movements
    const cfIncome  = cashflows.filter(f => f.type === 'income').reduce((s, f) => s + f.amount, 0);
    const cfExpense = cashflows.filter(f => f.type === 'expense').reduce((s, f) => s + f.amount, 0);
    const cfBalance = cfIncome - cfExpense;

    // Last 7 days chart data
    const days7 = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(d.getDate() - i);
      const dayStr = d.toDateString();
      const rev = sales.filter(s => new Date(s.date).toDateString() === dayStr).reduce((s, v) => s + v.total, 0);
      const cost = purchases.filter(p => new Date(p.date).toDateString() === dayStr).reduce((s, v) => s + v.total, 0);
      days7.push({ label: d.toLocaleDateString('es-MX', { weekday: 'short' }), rev, cost, day: d });
    }

    // Recent movements
    const recent = [...movements].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 8);
    const typeIcons = {
      entry: `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect width="22" height="22" rx="6" fill="#22c55e22"/><path d="M6 8h2v6H6zm8 0h2v6h-2zm-6 2.5h6M9 8V6.5a1 1 0 012 0V8m0 6v1.5a1 1 0 01-2 0V14" stroke="#22c55e" stroke-width="1.4" stroke-linecap="round"/></svg>`,
      sale:  `<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect width="22" height="22" rx="6" fill="#3b82f622"/><path d="M7 7h1l1.5 6h5l1-4H9.5" stroke="#3b82f6" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10.5" cy="15.5" r="1" fill="#3b82f6"/><circle cx="14.5" cy="15.5" r="1" fill="#3b82f6"/></svg>`,
      consignment:`<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect width="22" height="22" rx="6" fill="#f59e0b22"/><path d="M7 11a4 4 0 018 0M11 7v1m-3.5 3.5l.7.7M14.5 11.5l.7-.7" stroke="#f59e0b" stroke-width="1.4" stroke-linecap="round"/><path d="M8 13h6v3a1 1 0 01-1 1H9a1 1 0 01-1-1v-3z" stroke="#f59e0b" stroke-width="1.4"/></svg>`,
      return:`<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect width="22" height="22" rx="6" fill="#6366f122"/><path d="M8 10H15M8 10l2-2M8 10l2 2M14 12v2a1 1 0 01-1 1H9" stroke="#6366f1" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
      adjustment:`<svg width="22" height="22" viewBox="0 0 22 22" fill="none"><rect width="22" height="22" rx="6" fill="#ec489922"/><path d="M7 9h1.5m6 0H16m-7.5 0a1.5 1.5 0 003 0m-3 0a1.5 1.5 0 013 0M7 13h4m2.5 0H16m-4.5 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0" stroke="#ec4899" stroke-width="1.4" stroke-linecap="round"/></svg>`,
    };
    const movRows = recent.map(m => `
      <div class="activity-row">
        <span class="activity-icon">${typeIcons[m.type] || '·'}</span>
        <span class="activity-name">${m.productName}</span>
        <span class="activity-qty" style="color:${m.quantity>0?'var(--green)':'var(--red)'}">${m.quantity>0?'+':''}${m.quantity}</span>
        <span class="activity-date">${Utils.datetime(m.date)}</span>
      </div>`).join('');

    // Low stock list
    const alertRows = [...outStock, ...lowStock].slice(0, 6).map(p => `
      <div class="alert-row">
        <span>${p.name}</span>
        ${Utils.stockBadge(p.stock||0, p.minStock||5)}
        <span class="alert-stock">${p.stock||0} uds</span>
      </div>`).join('');

    // Mini dual bar chart (revenue vs purchases last 7 days)
    const maxVal = Math.max(...days7.map(d => Math.max(d.rev, d.cost)), 1);
    const miniChart = days7.map(d => `
      <div class="mini-bar-col">
        <div class="mini-bar-pair">
          <div class="mini-bar rev" style="height:${Math.max((d.rev/maxVal)*80,2)}px" title="Ventas: ${Utils.currency(d.rev)}"></div>
          <div class="mini-bar cost" style="height:${Math.max((d.cost/maxVal)*80,2)}px" title="Compras: ${Utils.currency(d.cost)}"></div>
        </div>
        <div class="mini-bar-label">${d.label}</div>
      </div>`).join('');

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Dashboard</h1>
          <p class="page-sub">${now.toLocaleDateString('es-MX', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</p>
        </div>
      </div>

      <div class="stats-grid">
        ${statCard('Ventas Hoy', Utils.currency(todayRevenue), `${todaySales.length} transacciones`, '💳', 'ventas')}
        ${statCard('Productos', products.length, 'en catálogo', '📦', 'productos')}
        ${statCard('Alertas Stock', outStock.length + lowStock.length, `${outStock.length} agotados`, '⚠️', 'reportes')}
        ${statCard('Consignaciones', pendingCS.length, 'con items pendientes', '🤝', 'consignaciones')}
      </div>

      <!-- Financial P&L Strip -->
      <div class="pnl-strip">
        <div class="pnl-item">
          <div class="pnl-label">Ingresos totales</div>
          <div class="pnl-value income">${Utils.currency(totalRevenue)}</div>
        </div>
        <div class="pnl-divider">−</div>
        <div class="pnl-item">
          <div class="pnl-label">Costo de ventas</div>
          <div class="pnl-value cost">${Utils.currency(salesCost)}</div>
        </div>
        <div class="pnl-divider">=</div>
        <div class="pnl-item highlight">
          <div class="pnl-label">Ganancia neta</div>
          <div class="pnl-value profit ${netProfit < 0 ? 'negative' : ''}">${Utils.currency(netProfit)}</div>
          <div class="pnl-margin">${Utils.pct(profitMargin)} margen</div>
        </div>
        <div class="pnl-sep"></div>
        <div class="pnl-item">
          <div class="pnl-label">Invertido en stock</div>
          <div class="pnl-value purchases">${Utils.currency(totalPurchaseCost)}</div>
          <div class="pnl-margin">stock actual × precio compra</div>
        </div>
        <div class="pnl-sep"></div>
        <div class="pnl-item clickable" onclick="App.navigate('flujo')" title="Ver flujo de caja">
          <div class="pnl-label">Otros movimientos</div>
          <div class="pnl-value profit ${cfBalance < 0 ? 'negative' : ''}">${Utils.currency(cfBalance)}</div>
          <div class="pnl-margin">${Utils.currency(cfIncome)} in · ${Utils.currency(cfExpense)} out</div>
        </div>
      </div>

      <!-- 7-Day Chart + Activity -->
      <div class="dashboard-grid dashboard-grid-3">
        <div class="dash-card">
          <h3>Ventas vs Compras — 7 días
            <span class="chart-legend">
              <span class="leg rev">Ventas</span>
              <span class="leg cost">Compras</span>
            </span>
          </h3>
          <div class="mini-chart">${miniChart}</div>
        </div>
        <div class="dash-card">
          <h3>Actividad reciente</h3>
          ${recent.length ? movRows : '<div class="empty-state" style="padding:16px"><span>🔄</span><p>Sin actividad</p></div>'}
        </div>
        <div class="dash-card">
          <h3>Alertas de inventario ${outStock.length + lowStock.length > 0 ? `<span class="badge badge-danger">${outStock.length + lowStock.length}</span>` : ''}</h3>
          ${alertRows || '<div class="empty-state" style="padding:16px"><span>✅</span><p>Todo en orden</p></div>'}
          ${outStock.length + lowStock.length > 6 ? `<button class="btn btn-ghost btn-sm" style="margin-top:8px" onclick="App.navigate('reportes')">Ver todos →</button>` : ''}
        </div>
      </div>`;
  }

  const statCard = (title, value, sub, icon, route) => `
    <div class="stat-card ${route ? 'clickable' : ''}" ${route ? `onclick="App.navigate('${route}')"` : ''}>
      <div class="stat-icon">${icon}</div>
      <div class="stat-body">
        <div class="stat-value">${value}</div>
        <div class="stat-title">${title}</div>
        <div class="stat-sub">${sub}</div>
      </div>
    </div>`;

  // ── Settings ─────────────────────────────────────────────────
  async function showSettings() {
    const theme = await GymDB.getSetting('theme') || 'light';
    const accent = await GymDB.getSetting('accent') || '#22c55e';
    const accent2 = await GymDB.getSetting('accent2') || '#3b82f6';
    const storeName = await GymDB.getSetting('storeName') || 'GymStockPro';
    const currency = await GymDB.getSetting('currency') || '$';
    const session = await fetch('/api/session', { credentials: 'same-origin' })
      .then(r => r.json()).catch(() => ({}));

    const accessCard = `
      <div class="settings-card">
        <h3>📱 Acceso desde el celular</h3>
        ${session.remote ? `
          <p style="color:var(--text-muted);font-size:14px;line-height:1.6">
            Estás conectado desde fuera de la red local.<br>
            Por seguridad, el PIN solo puede cambiarse desde la computadora
            donde corre el servidor.
          </p>` : `
          <p style="color:var(--text-muted);font-size:14px;margin-bottom:12px;line-height:1.55">
            Este PIN se pide al abrir la app desde el celular por el túnel.
            En esta computadora nunca se pide.
          </p>
          <div class="form-group">
            <label>${session.pinConfigured ? 'Cambiar PIN' : 'Definir PIN'} (mínimo 4 caracteres)</label>
            <input id="set-pin" type="password" inputmode="numeric" autocomplete="new-password"
                   class="form-input" placeholder="••••" style="max-width:180px">
          </div>
          <button class="btn btn-primary" onclick="App.savePin()">Guardar PIN</button>
          <p style="margin-top:12px;font-size:13px;color:${session.pinConfigured ? 'var(--green)' : 'var(--red)'}">
            ${session.pinConfigured
              ? '✓ PIN configurado — el acceso remoto está habilitado.'
              : '⚠ Sin PIN: el acceso por el túnel está bloqueado.'}
          </p>`}
      </div>`;

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div><h1>Configuración</h1><p class="page-sub">Personaliza tu sistema</p></div>
      </div>

      <div class="settings-grid">
        <div class="settings-card">
          <h3>🏪 Información de la Tienda</h3>
          <div class="form-group">
            <label>Nombre de la tienda</label>
            <input id="set-storename" class="form-input" value="${storeName}">
          </div>
          <div class="form-group">
            <label>Símbolo de moneda</label>
            <input id="set-currency" class="form-input" value="${currency}" style="max-width:80px">
          </div>
          <button class="btn btn-primary" onclick="App.saveGeneralSettings()">Guardar</button>
        </div>

        <div class="settings-card">
          <h3>🎨 Apariencia</h3>
          <div class="form-group">
            <label>Tema</label>
            <div class="theme-toggle">
              <button class="theme-btn ${theme==='light'?'active':''}" onclick="App.setTheme('light')">☀️ Claro</button>
              <button class="theme-btn ${theme==='dark'?'active':''}" onclick="App.setTheme('dark')">🌙 Oscuro</button>
            </div>
          </div>
          <div class="form-group">
            <label>Color acento principal</label>
            <div class="color-row">
              <input id="set-accent" type="color" class="color-picker" value="${accent}" oninput="App.previewAccent(this.value)">
              <span id="accent-hex">${accent}</span>
              <div class="color-presets">
                ${['#22c55e','#10b981','#3b82f6','#8b5cf6','#f59e0b','#ef4444','#ec4899','#14b8a6'].map(c=>
                  `<button class="color-preset" style="background:${c}" onclick="document.getElementById('set-accent').value='${c}';App.previewAccent('${c}')"></button>`
                ).join('')}
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Color acento secundario</label>
            <div class="color-row">
              <input id="set-accent2" type="color" class="color-picker" value="${accent2}" oninput="App.previewAccent2(this.value)">
              <span id="accent2-hex">${accent2}</span>
              <div class="color-presets">
                ${['#3b82f6','#6366f1','#8b5cf6','#ec4899','#f97316','#22c55e','#06b6d4','#f59e0b'].map(c=>
                  `<button class="color-preset" style="background:${c}" onclick="document.getElementById('set-accent2').value='${c}';App.previewAccent2('${c}')"></button>`
                ).join('')}
              </div>
            </div>
          </div>
          <button class="btn btn-primary" onclick="App.saveAppearance()">Aplicar</button>
        </div>

        <div class="settings-card">
          <h3>🗃 Datos</h3>
          <p style="color:var(--text-muted);font-size:14px;margin-bottom:12px">Exporta o importa tus datos en formato JSON para respaldo.</p>
          <div class="action-btns" style="flex-wrap:wrap;gap:8px">
            <button class="btn btn-ghost" onclick="App.exportData()">⬇️ Exportar datos</button>
            <button class="btn btn-ghost" onclick="document.getElementById('import-file').click()">⬆️ Importar datos</button>
            <button class="btn btn-danger-ghost" onclick="App.clearData()">🗑 Limpiar todo</button>
          </div>
          <input type="file" id="import-file" accept=".json" style="display:none" onchange="App.importData(this)">
        </div>

        ${accessCard}
      </div>`;
  }

  // ── Settings Actions ─────────────────────────────────────────
  const saveGeneralSettings = async () => {
    const name = document.getElementById('set-storename').value.trim() || 'GymStockPro';
    const cur = document.getElementById('set-currency').value.trim() || '$';
    await GymDB.setSetting('storeName', name);
    await GymDB.setSetting('currency', cur);
    window.APP_STORE = name; window.APP_CURRENCY = cur;
    document.getElementById('brand-name').textContent = name;
    document.getElementById('mobile-title').textContent = name;
    Utils.toast('Configuración guardada');
  };

  const setTheme = async (theme) => {
    document.documentElement.dataset.theme = theme;
    await GymDB.setSetting('theme', theme);
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.theme-btn:${theme==='dark'?'last':'first'}-child`)?.classList.add('active');
    Utils.toast(`Tema ${theme === 'dark' ? 'oscuro' : 'claro'} activado`);
  };

  const previewAccent = (val) => {
    document.documentElement.style.setProperty('--accent', val);
    const el = document.getElementById('accent-hex'); if (el) el.textContent = val;
  };
  const previewAccent2 = (val) => {
    document.documentElement.style.setProperty('--accent-2', val);
    const el = document.getElementById('accent2-hex'); if (el) el.textContent = val;
  };

  const saveAppearance = async () => {
    const accent = document.getElementById('set-accent').value;
    const accent2 = document.getElementById('set-accent2').value;
    await GymDB.setSetting('accent', accent);
    await GymDB.setSetting('accent2', accent2);
    Utils.toast('Apariencia guardada');
  };

  const exportData = async () => {
    const stores = ['products','movements','sales','consignments','clients','suppliers','purchases','settings','cashflows'];
    const data = {};
    for (const s of stores) data[s] = await GymDB.getAll(s);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `gymstockpro_backup_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    Utils.toast('Datos exportados');
  };

  const importData = async (input) => {
    const file = input.files[0]; if (!file) return;
    input.value = '';
    const text = await file.text();
    const data = JSON.parse(text);
    const ok = await Utils.confirm('¿Importar datos? Esto SOBREESCRIBIRÁ todo el contenido actual.');
    if (!ok) return;
    const stores = ['products','movements','sales','consignments','clients','suppliers','purchases','settings','cashflows'];
    try {
      for (const s of stores) {
        if (!Array.isArray(data[s])) continue;
        await GymDB.bulkPut(s, data[s]);   // una sola llamada por store
      }
    } catch (err) {
      Utils.toast(`No se pudo importar: ${err.message}`, 'error');
      return;
    }
    Utils.toast('Datos importados correctamente');
    navigate('dashboard');
  };

  const clearData = async () => {
    const ok = await Utils.confirm('¿ELIMINAR TODOS LOS DATOS? Esta acción es irreversible.');
    if (!ok) return;
    const stores = ['products','movements','sales','consignments','clients','suppliers','purchases','cashflows'];
    try {
      for (const s of stores) {
        const all = await GymDB.getAll(s);
        await GymDB.bulkRemove(s, all.map(i => i.id));
      }
    } catch (err) {
      Utils.toast(`No se pudo limpiar: ${err.message}`, 'error');
      return;
    }
    Utils.toast('Todos los datos eliminados', 'info');
    navigate('dashboard');
  };

  // ── PIN de acceso remoto ─────────────────────────────────────
  const savePin = async () => {
    const pin = document.getElementById('set-pin')?.value.trim() || '';
    if (pin.length < 4) { Utils.toast('El PIN debe tener al menos 4 caracteres', 'error'); return; }
    try {
      const res = await fetch('/api/set-pin', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { Utils.toast(data.error || 'No se pudo guardar', 'error'); return; }
      document.getElementById('set-pin').value = '';
      Utils.toast('PIN actualizado. Los celulares deberán entrar de nuevo.');
      showSettings();
    } catch (_) {
      Utils.toast('Sin conexión con el servidor', 'error');
    }
  };

  // ── Init ─────────────────────────────────────────────────────
  const init = async () => {
    // GymDB.init() ya corrio en Sync.boot() (maneja PIN y migracion).

    // Load saved settings
    const [theme, accent, accent2, storeName, currency] = await Promise.all([
      GymDB.getSetting('theme'), GymDB.getSetting('accent'),
      GymDB.getSetting('accent2'), GymDB.getSetting('storeName'),
      GymDB.getSetting('currency')
    ]);

    if (theme) document.documentElement.dataset.theme = theme;
    if (accent) document.documentElement.style.setProperty('--accent', accent);
    if (accent2) document.documentElement.style.setProperty('--accent-2', accent2);
    window.APP_STORE = storeName || 'GymStockPro';
    window.APP_CURRENCY = currency || 'Q';
    document.getElementById('brand-name').textContent = window.APP_STORE;
    document.getElementById('mobile-title').textContent = window.APP_STORE;

    // Build nav (barra lateral en escritorio)
    const nav = document.getElementById('nav-items');
    nav.innerHTML = Object.entries(ROUTES).map(([key, r]) => `
      <li class="nav-item" data-route="${key}" onclick="App.navigate('${key}')">
        <span class="nav-icon">${r.icon}</span>
        <span class="nav-label">${r.label}</span>
      </li>`).join('');

    // Build nav (barra inferior en celular + hoja "Más")
    const entries = Object.entries(ROUTES);
    const tabBar = document.getElementById('mobile-nav');
    if (tabBar) {
      tabBar.innerHTML = entries.filter(([, r]) => r.mobile).map(([key, r]) => `
        <button class="nav-item tab-item" data-route="${key}" onclick="App.navigate('${key}')">
          <span class="nav-icon">${r.icon}</span>
          <span class="tab-label">${r.short}</span>
        </button>`).join('') + `
        <button class="tab-item" id="nav-more-btn" onclick="App.openMoreSheet()">
          <span class="nav-icon">⋯</span>
          <span class="tab-label">Más</span>
        </button>`;
    }
    const sheet = document.getElementById('more-sheet-items');
    if (sheet) {
      sheet.innerHTML = entries.filter(([, r]) => !r.mobile).map(([key, r]) => `
        <button class="nav-item sheet-item" data-route="${key}" onclick="App.navigate('${key}')">
          <span class="nav-icon">${r.icon}</span>
          <span>${r.label}</span>
        </button>`).join('');
    }

    // Restore last route
    const lastRoute = localStorage.getItem('gymsp_route') || 'dashboard';
    navigate(lastRoute);

    // Hide loading screen
    document.getElementById('loading-screen').style.display = 'none';
    document.getElementById('app-shell').style.display = 'flex';
  };

  /** Vuelve a dibujar la vista actual (tras un cambio hecho en otro dispositivo). */
  const reload = () => navigate(currentRoute);

  return { navigate, reload, openMoreSheet, closeMoreSheet, init, saveGeneralSettings, setTheme, previewAccent, previewAccent2, saveAppearance, exportData, importData, clearData, savePin };
})();
