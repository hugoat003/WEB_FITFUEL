// GymStockPro — Consignment Module
window.ConsignmentModule = (() => {

  // Clave de día (local, coincide con lo que muestra Utils.date) para agrupar consignaciones
  const dayKey = (iso) => {
    const d = new Date(iso);
    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  };

  const render = async () => {
    const consignments = await GymDB.getAll('consignments');
    const clients = await GymDB.getAll('clients');
    consignments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const clientMap = Object.fromEntries(clients.map(c => [c.id, c.name]));

    // Unificar SOLO en la vista: UNA fila por cliente. Las fechas diferencian
    // cada consignación dentro de "Gestionar". Los registros guardados no se modifican.
    const groupsMap = new Map();
    for (const c of consignments) {
      if (!groupsMap.has(c.clientId)) {
        groupsMap.set(c.clientId, { clientId: c.clientId, items: [], days: new Map() });
      }
      const g = groupsMap.get(c.clientId);
      g.items.push(...(c.items || []));
      const dk = dayKey(c.createdAt);
      // Guarda el timestamp más reciente de cada día (para ordenar/mostrar la fecha)
      if (!g.days.has(dk) || new Date(c.createdAt) > new Date(g.days.get(dk))) g.days.set(dk, c.createdAt);
    }
    const groups = [...groupsMap.values()];

    const rows = groups.map(g => {
      const pending = g.items.filter(i => i.status === 'pendiente').length;
      const sold = g.items.filter(i => i.status === 'vendido').length;
      const returned = g.items.filter(i => i.status === 'devuelto').length;
      const dates = [...g.days.values()]
        .sort((a, b) => new Date(b) - new Date(a))
        .map(d => Utils.date(d))
        .join(', ');
      return [
        clientMap[g.clientId] || '—',
        dates,
        g.items.length,
        pending ? `<span class="badge badge-warning">${pending} pendiente(s)</span>` : '—',
        sold ? `<span class="badge badge-ok">${sold} vendido(s)</span>` : '—',
        returned ? `<span class="badge badge-info">${returned} devuelto(s)</span>` : '—',
        `<div class="action-btns">
          <button class="btn btn-sm btn-primary" onclick="ConsignmentModule.manageClient(${g.clientId})">Gestionar</button>
          ${pending ? `<button class="btn btn-sm btn-ghost" title="Ticket de lo que tiene en su poder"
             onclick="ConsignmentModule.ticket(${g.clientId})">🧾 Ticket</button>` : ''}
          <button class="btn btn-sm btn-danger-ghost" onclick="ConsignmentModule.deleteClientGroup(${g.clientId})">🗑</button>
        </div>`
      ];
    });

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Consignaciones</h1>
          <p class="page-sub">${groups.length} cliente(s) con consignaciones — ${groups.filter(g=>g.items.some(i=>i.status==='pendiente')).length} con items pendientes</p>
        </div>
        <div class="header-actions">
          <button class="btn btn-ghost" onclick="ConsignmentModule.renderClients()">👥 Clientes</button>
          <button class="btn btn-primary" onclick="ConsignmentModule.newConsignment()">+ Nueva Consignación</button>
        </div>
      </div>
      ${Utils.table(['Cliente','Fechas','Items','Pendientes','Vendidos','Devueltos','Acciones'], rows, { emptyMsg: 'No hay consignaciones registradas', scroll: true })}
    `;
  };

  const renderClients = async () => {
    const clients = await GymDB.getAll('clients');
    const rows = clients.map(c => [
      `<b>${c.name}</b>`,
      c.phone || '—',
      c.email || '—',
      c.address || '—',
      `<div class="action-btns">
        <button class="btn btn-sm btn-ghost" onclick="ConsignmentModule.editClient(${c.id})">✏️</button>
        <button class="btn btn-sm btn-danger-ghost" onclick="ConsignmentModule.deleteClient(${c.id})">🗑</button>
      </div>`
    ]);

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Clientes</h1>
          <p class="page-sub">${clients.length} clientes registrados</p>
        </div>
        <div class="header-actions">
          <button class="btn btn-ghost" onclick="ConsignmentModule.render()">← Consignaciones</button>
          <button class="btn btn-primary" onclick="ConsignmentModule.addClient()">+ Nuevo Cliente</button>
        </div>
      </div>
      ${Utils.table(['Nombre','Teléfono','Email','Dirección','Acciones'], rows, { emptyMsg: 'No hay clientes registrados', scroll: true })}
    `;
  };

  const clientFormHTML = (c = {}) => `
    <div class="form-grid">
      <div class="form-group form-col-2">
        <label>Nombre *</label>
        <input id="c-name" class="form-input" value="${c.name||''}" placeholder="Nombre completo">
      </div>
      <div class="form-group">
        <label>Teléfono</label>
        <input id="c-phone" class="form-input" value="${c.phone||''}" placeholder="+52 000 000 0000">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input id="c-email" class="form-input" type="email" value="${c.email||''}" placeholder="correo@ejemplo.com">
      </div>
      <div class="form-group form-col-2">
        <label>Dirección</label>
        <input id="c-address" class="form-input" value="${c.address||''}" placeholder="Dirección">
      </div>
      <div class="form-group form-col-2">
        <label>Notas</label>
        <textarea id="c-notes" class="form-input" rows="2">${c.notes||''}</textarea>
      </div>
    </div>`;

  const addClient = async () => {
    const r = await Utils.modal('Nuevo Cliente', clientFormHTML());
    if (r !== 'confirm') return;
    if (!Utils.val('c-name')) { Utils.toast('El nombre es requerido', 'error'); return; }
    await GymDB.add('clients', {
      name: Utils.val('c-name'), phone: Utils.val('c-phone'),
      email: Utils.val('c-email'), address: Utils.val('c-address'),
      notes: Utils.val('c-notes'), createdAt: new Date().toISOString()
    });
    Utils.toast('Cliente agregado');
    renderClients();
  };

  const editClient = async (id) => {
    const c = await GymDB.getById('clients', id);
    const r = await Utils.modal('Editar Cliente', clientFormHTML(c));
    if (r !== 'confirm') return;
    await GymDB.put('clients', { ...c, name: Utils.val('c-name'), phone: Utils.val('c-phone'), email: Utils.val('c-email'), address: Utils.val('c-address'), notes: Utils.val('c-notes') });
    Utils.toast('Cliente actualizado');
    renderClients();
  };

  const deleteClient = async (id) => {
    const ok = await Utils.confirm('¿Eliminar este cliente?');
    if (!ok) return;
    await GymDB.remove('clients', id);
    Utils.toast('Cliente eliminado', 'info');
    renderClients();
  };

  const newConsignment = async () => {
    const clients = await GymDB.getAll('clients');
    const products = await GymDB.getAll('products');
    if (!clients.length) { Utils.toast('Primero agrega un cliente', 'error'); return; }

    const clientOpts = clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    const productOpts = products.filter(p => (p.stock||0) > 0)
      .map(p => `<option value="${p.id}" data-price="${p.wholesalePrice || p.salePrice}" data-stock="${p.stock}">${p.name} (Stock: ${p.stock})</option>`).join('');

    const body = `
      <div class="form-grid">
        <div class="form-group form-col-2">
          <label>Cliente *</label>
          <select id="cs-client" class="form-input">${clientOpts}</select>
        </div>
      </div>
      <div class="cart-add-row">
        <select id="cs-product" class="form-input" style="flex:2">${productOpts}</select>
        <input id="cs-qty" type="number" class="form-input" value="1" min="1" style="width:80px">
        <button class="btn btn-accent" onclick="ConsignmentModule._addItem()">+ Agregar</button>
      </div>
      <div id="cs-items-table"><div class="empty-state" style="padding:20px"><span>📋</span><p>Sin productos</p></div></div>`;

    window._csItems = [];
    const r = await Utils.modal('Nueva Consignación', body, { wide: true, confirmLabel: 'Crear Consignación' });
    if (r !== 'confirm') return;
    if (!window._csItems.length) { Utils.toast('Agrega al menos un producto', 'error'); return; }

    const clientId = parseInt(Utils.val('cs-client'));
    const now = new Date().toISOString();
    const id = await GymDB.add('consignments', {
      clientId, items: window._csItems.map(i => ({ ...i, status: 'pendiente' })),
      createdAt: now, updatedAt: now
    });

    for (const item of window._csItems) {
      await GymDB.updateStock(item.productId, -item.quantity, 'consignment', `Consignación #${id}`);
    }

    Utils.toast('Consignación registrada');
    // Flujo de entrega: acabas de dejar producto, así que el ticket se abre
    // enseguida con todo lo que queda en poder del cliente.
    await ticket(clientId);
    render();
  };

  window.ConsignmentModule = window.ConsignmentModule || {};
  window.ConsignmentModule._addItem = () => {
    const sel = document.getElementById('cs-product');
    const pid = parseInt(sel.value);
    const qty = parseInt(document.getElementById('cs-qty').value) || 1;
    const opt = sel.options[sel.selectedIndex];
    const stock = parseInt(opt.dataset.stock);
    if (qty > stock) { Utils.toast(`Solo hay ${stock} en stock`, 'error'); return; }
    const price = parseFloat(opt.dataset.price);
    const existing = window._csItems.find(i => i.productId === pid);
    if (existing) existing.quantity += qty;
    else window._csItems.push({ productId: pid, productName: opt.text.split(' (Stock')[0], quantity: qty, salePrice: price });
    refreshCSTable();
  };

  const refreshCSTable = () => {
    const rows = window._csItems.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.salePrice)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="window._csItems.splice(${i},1);ConsignmentModule._refreshCSTable()">✕</button></td>
      </tr>`).join('');
    document.getElementById('cs-items-table').innerHTML = window._csItems.length ? `
      <div class="table-wrap table-scroll">
        <table class="data-table">
          <thead><tr><th>Producto</th><th>Cant.</th><th>Precio Mayoreo</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>` : `<div class="empty-state" style="padding:20px"><span>📋</span><p>Sin productos</p></div>`;
  };
  window.ConsignmentModule._refreshCSTable = refreshCSTable;

  // ── Ticket para el cliente ──────────────────────────────────────
  // "Lo que tiene en sus manos" = todo lo que sigue en estado pendiente.
  // Se agrupa por la fecha REAL de cada entrega (no se consolida como en
  // la vista de gestión), porque el cliente necesita ver qué se le dejó
  // cada día y qué de eso no ha vendido.
  const pendingByDate = (group) => {
    const byDay = new Map();
    for (const cs of group) {
      for (const item of (cs.items || [])) {
        if (item.status !== 'pendiente') continue;
        const dk = dayKey(cs.createdAt);
        if (!byDay.has(dk)) byDay.set(dk, { date: cs.createdAt, items: [] });
        const block = byDay.get(dk);
        if (new Date(cs.createdAt) > new Date(block.date)) block.date = cs.createdAt;
        // Une el mismo producto al mismo precio dentro del mismo día
        const same = block.items.find(i => i.productId === item.productId
                                        && i.salePrice === item.salePrice);
        if (same) same.quantity += item.quantity;
        else block.items.push({ ...item });
      }
    }
    return [...byDay.values()].sort((a, b) => new Date(b.date) - new Date(a.date));
  };

  const blockTotal = (block) =>
    block.items.reduce((s, i) => s + i.quantity * (i.salePrice || 0), 0);
  const blockUnits = (block) =>
    block.items.reduce((s, i) => s + i.quantity, 0);

  const isToday = (iso) => new Date(iso).toDateString() === new Date().toDateString();

  /** Versión en texto plano, para compartir por WhatsApp. */
  const ticketText = (client, blocks) => {
    const lines = [];
    lines.push(`${window.APP_STORE || 'GymStockPro'} — Consignación`);
    lines.push(`Cliente: ${client?.name || '—'}`);
    lines.push(`Emitido: ${Utils.datetime(new Date().toISOString())}`);
    lines.push('');
    for (const b of blocks) {
      lines.push(`${Utils.date(b.date)}${isToday(b.date) ? ' (entregado hoy)' : ''}`);
      for (const i of b.items) {
        lines.push(`  ${i.quantity} x ${i.productName} — ${Utils.currency(i.salePrice)} c/u` +
                   ` = ${Utils.currency(i.quantity * i.salePrice)}`);
      }
      lines.push(`  Subtotal: ${Utils.currency(blockTotal(b))}`);
      lines.push('');
    }
    const units = blocks.reduce((s, b) => s + blockUnits(b), 0);
    const total = blocks.reduce((s, b) => s + blockTotal(b), 0);
    lines.push(`TOTAL EN CONSIGNACIÓN: ${units} unidad(es) — ${Utils.currency(total)}`);
    return lines.join('\n');
  };

  /** Ventana imprimible (misma estética que el comprobante de venta). */
  const ticketPrintHTML = (client, blocks) => {
    const store = window.APP_STORE || 'GymStockPro';
    const units = blocks.reduce((s, b) => s + blockUnits(b), 0);
    const total = blocks.reduce((s, b) => s + blockTotal(b), 0);

    const sections = blocks.map(b => `
      <div class="daysec">
        <div class="dayhead">${Utils.date(b.date)}${isToday(b.date)
          ? ' <span class="tag">entregado hoy</span>' : ''}</div>
        <table>
          <thead><tr><th>Producto</th><th class="c">Cant.</th><th class="r">P.Unit</th><th class="r">Total</th></tr></thead>
          <tbody>${b.items.map(i => `
            <tr>
              <td>${i.productName}</td>
              <td class="c">${i.quantity}</td>
              <td class="r">${Utils.currency(i.salePrice)}</td>
              <td class="r">${Utils.currency(i.quantity * i.salePrice)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
        <div class="subtotal">Subtotal: <b>${Utils.currency(blockTotal(b))}</b></div>
      </div>`).join('');

    return `<!DOCTYPE html><html lang="es"><head>
      <meta charset="UTF-8"><title>Consignación — ${client?.name || ''}</title>
      <style>
        body{font-family:monospace;padding:20px;font-size:13px;max-width:400px;margin:0 auto;color:#000}
        h2{text-align:center;font-size:16px;margin:0}
        .sub{text-align:center;color:#555;margin-bottom:14px;font-size:12px}
        .cliente{font-size:13px;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #000}
        .daysec{margin-bottom:14px}
        .dayhead{font-weight:bold;font-size:12.5px;background:#f0f0f0;padding:4px 6px;margin-bottom:4px}
        .tag{font-weight:normal;font-size:10px;background:#000;color:#fff;padding:1px 5px;border-radius:3px}
        table{width:100%;border-collapse:collapse}
        th{border-bottom:1px solid #000;padding:3px 2px;font-size:10.5px;text-align:left}
        td{padding:3px 2px;border-bottom:1px dotted #ccc;font-size:11.5px}
        .c{text-align:center}.r{text-align:right}
        .subtotal{text-align:right;font-size:11.5px;margin-top:3px}
        .total{font-weight:bold;font-size:14px;text-align:right;margin-top:14px;padding-top:8px;border-top:2px solid #000}
        .units{font-size:11px;color:#555;text-align:right;font-weight:normal}
        .firma{margin-top:34px;font-size:11px;color:#555}
        .linea{border-top:1px solid #000;margin-top:26px;padding-top:4px;text-align:center}
        .footer{text-align:center;margin-top:14px;font-size:10.5px;color:#888}
        @media print{button{display:none}}
      </style></head><body>
      <h2>${store}</h2>
      <div class="sub">Comprobante de consignación<br>${Utils.datetime(new Date().toISOString())}</div>
      <div class="cliente">Cliente: <b>${client?.name || '—'}</b>${
        client?.phone ? `<br>Tel: ${client.phone}` : ''}</div>
      ${sections}
      <div class="total">TOTAL: ${Utils.currency(total)}</div>
      <div class="units">${units} unidad(es) en consignación</div>
      <div class="firma">
        Producto entregado en consignación. El pago corresponde
        únicamente a las unidades vendidas.
        <div class="linea">Firma de recibido</div>
      </div>
      <div class="footer">Documento informativo — no es factura</div>
      <br><button onclick="window.print()">🖨 Imprimir</button>
      </body></html>`;
  };

  const ticket = async (clientId) => {
    const all = await GymDB.getAll('consignments');
    const group = all.filter(c => c.clientId === clientId);
    const client = await GymDB.getById('clients', clientId);
    const blocks = pendingByDate(group);

    if (!blocks.length) {
      Utils.toast('Este cliente no tiene productos pendientes', 'info');
      return;
    }

    const units = blocks.reduce((s, b) => s + blockUnits(b), 0);
    const total = blocks.reduce((s, b) => s + blockTotal(b), 0);

    // Lista compacta (no Utils.table): un ticket debe leerse de un vistazo,
    // no convertirse en una tarjeta de cuatro filas por producto.
    const preview = blocks.map(b => `
      <div class="ticket-block">
        <div class="ticket-date">
          <span>📅 ${Utils.date(b.date)}</span>
          ${isToday(b.date) ? '<span class="badge badge-ok">entregado hoy</span>' : ''}
        </div>
        ${b.items.map(i => `
          <div class="ticket-line">
            <div class="tl-name">${i.productName}</div>
            <div class="tl-total">${Utils.currency(i.quantity * i.salePrice)}</div>
            <div class="tl-meta">${i.quantity} × ${Utils.currency(i.salePrice)}</div>
          </div>`).join('')}
        <div class="ticket-subtotal">
          ${blockUnits(b)} uds · Subtotal <b>${Utils.currency(blockTotal(b))}</b>
        </div>
      </div>`).join('');

    const body = `
      <div class="ticket-head">
        <div>
          <div class="ticket-label">Cliente</div>
          <div class="ticket-client">${client?.name || '—'}</div>
        </div>
        <div style="text-align:right">
          <div class="ticket-label">En su poder</div>
          <div class="ticket-client">${units} uds</div>
        </div>
      </div>
      ${preview}
      <div class="ticket-total">
        <span>Total en consignación</span>
        <b>${Utils.currency(total)}</b>
      </div>`;

    window._csTicket = { client, blocks };

    await Utils.modal(`Ticket de consignación — ${client?.name || ''}`, body, {
      wide: true,
      buttons: [
        { label: '🖨 Imprimir', cls: 'btn-primary', value: 'print' },
        { label: '📲 Compartir', cls: 'btn-accent', value: 'share' },
        { label: 'Cerrar', cls: 'btn-ghost', value: 'cancel' },
      ]
    }).then(async (action) => {
      const { client: cl, blocks: bl } = window._csTicket;
      if (action === 'print') {
        const w = window.open('', '_blank', 'width=440,height=680');
        if (!w) { Utils.toast('El navegador bloqueó la ventana de impresión', 'error'); return; }
        w.document.write(ticketPrintHTML(cl, bl));
        w.document.close();
      } else if (action === 'share') {
        const text = ticketText(cl, bl);
        if (navigator.share) {
          try { await navigator.share({ title: 'Consignación', text }); }
          catch (_) { /* el usuario canceló */ }
        } else if (navigator.clipboard) {
          try {
            await navigator.clipboard.writeText(text);
            Utils.toast('Ticket copiado — pégalo en WhatsApp');
          } catch (_) { Utils.toast('No se pudo copiar', 'error'); }
        } else {
          Utils.toast('Compartir no disponible en este navegador', 'error');
        }
      }
    });
  };

  // Gestiona TODAS las consignaciones de un cliente, separadas por fecha.
  // Cada item sigue ligado a su registro real (csId) — no se fusionan datos.
  const manageClient = async (clientId) => {
    const all = await GymDB.getAll('consignments');
    const group = all.filter(c => c.clientId === clientId);
    if (!group.length) { render(); return; }
    const client = await GymDB.getById('clients', clientId);

    // Fecha (día) más reciente del cliente: ahí se consolida TODO lo pendiente.
    let latestTs = group[0].createdAt;
    for (const cs of group) if (new Date(cs.createdAt) > new Date(latestTs)) latestTs = cs.createdAt;
    const latestDk = dayKey(latestTs);

    // Agrupar items por día. Los pendientes van todos al día más reciente;
    // los vendidos/devueltos quedan en su día original como historial.
    const byDay = new Map();
    const ensureBlock = (dk, date) => {
      if (!byDay.has(dk)) byDay.set(dk, { date, entries: [] });
      const b = byDay.get(dk);
      if (new Date(date) > new Date(b.date)) b.date = date;
      return b;
    };
    for (const cs of group) {
      const ownDk = dayKey(cs.createdAt);
      cs.items.forEach((item, idx) => {
        const toLatest = item.status === 'pendiente';
        const block = ensureBlock(toLatest ? latestDk : ownDk, toLatest ? latestTs : cs.createdAt);
        block.entries.push({ csId: cs.id, idx, item, originDate: cs.createdAt });
      });
    }
    const dayBlocks = [...byDay.values()].sort((a, b) => new Date(b.date) - new Date(a.date));

    const sections = dayBlocks.map(block => {
      const rows = block.entries.map(({ csId, idx, item, originDate }) => {
        const movedNote = (item.status === 'pendiente' && dayKey(originDate) !== latestDk)
          ? ` <span style="color:var(--text-muted);font-size:11px">(de ${Utils.date(originDate)})</span>` : '';
        return `
        <tr>
          <td>${item.productName}${movedNote}</td>
          <td>${item.quantity}</td>
          <td>${Utils.currency(item.salePrice)}</td>
          <td>${Utils.statusBadge(item.status)}</td>
          <td>
            ${item.status === 'pendiente' ? `
              <div class="action-btns">
                <button class="btn btn-sm btn-primary" onclick="ConsignmentModule._markSold(${csId}, ${idx})">✓ Vendido</button>
                <button class="btn btn-sm btn-ghost" onclick="ConsignmentModule._markReturned(${csId}, ${idx})">↩ Devolver todo</button>
              </div>` : `<span style="color:var(--text-muted);font-size:13px">—</span>`}
          </td>
        </tr>`;
      }).join('');
      return `
        <div style="margin:14px 0 6px;font-weight:600">📅 ${Utils.date(block.date)}</div>
        <div class="table-wrap table-scroll">
          <table class="data-table">
            <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Estado</th><th>Acciones</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    }).join('');

    const body = `
      <div class="info-row" style="margin-bottom:8px">
        <span>Cliente: <b>${client?.name || '—'}</b></span>
        <span><b>${dayBlocks.length}</b> fecha(s) — <b>${group.length}</b> consignación(es)</span>
      </div>
      ${sections}`;

    const hasPending = group.some(cs => cs.items?.some(i => i.status === 'pendiente'));
    const action = await Utils.modal(`Consignaciones — ${client?.name || ''}`, body, {
      wide: true,
      buttons: [
        ...(hasPending
          ? [{ label: '🧾 Generar ticket', cls: 'btn-primary', value: 'ticket' }]
          : []),
        { label: 'Cerrar', cls: 'btn-ghost', value: 'cancel' },
      ]
    });
    if (action === 'ticket') await ticket(clientId);
    render();
  };

  // Compatibilidad: gestionar por id individual redirige al grupo del cliente.
  const manage = async (id) => {
    const cs = await GymDB.getById('consignments', id);
    if (!cs) { render(); return; }
    return manageClient(cs.clientId);
  };

  window.ConsignmentModule._markSold = async (csId, idx) => {
    const cs = await GymDB.getById('consignments', csId);
    const item = cs.items[idx];
    if (!item || item.status !== 'pendiente') { manageClient(cs.clientId); return; }

    // Abrir diálogo propio para pedir la cantidad — evita leer el DOM tras await
    const dialogBody = `
      <div style="margin-bottom:16px">
        <p>Producto: <b>${item.productName}</b></p>
        <p style="color:var(--text-muted);font-size:13px">Unidades en consignación: <b>${item.quantity}</b></p>
      </div>
      <div class="form-group">
        <label>¿Cuántas unidades se vendieron?</label>
        <input id="cs-sold-qty" type="number" class="form-input"
          value="${item.quantity}" min="1" max="${item.quantity}" style="max-width:140px">
        <small style="color:var(--text-muted)">Máximo: ${item.quantity}</small>
      </div>`;

    const result = await Utils.modal(`Registrar venta — ${item.productName}`, dialogBody, {
      confirmLabel: 'Confirmar venta'
    });

    if (result !== 'confirm') { manageClient(cs.clientId); return; }

    // El valor se lee AQUÍ, dentro del mismo contexto del modal confirmado
    const inputEl  = document.getElementById('cs-sold-qty');
    const soldQty  = Math.min(Math.max(parseInt(inputEl?.value) || 1, 1), item.quantity);
    const remaining = item.quantity - soldQty;
    const now = new Date().toISOString();

    if (remaining > 0) {
      // Venta parcial: reemplazar item actual + agregar nuevo pendiente con el resto
      cs.items[idx] = { ...item, quantity: soldQty, status: 'vendido' };
      cs.items.push({ ...item, quantity: remaining, status: 'pendiente' });
    } else {
      cs.items[idx] = { ...item, status: 'vendido' };
    }
    cs.updatedAt = now;
    await GymDB.put('consignments', cs);

    const saleId = await GymDB.add('sales', {
      type: 'wholesale', clientId: cs.clientId,
      items: [{ productId: item.productId, productName: item.productName, quantity: soldQty, price: item.salePrice }],
      total: soldQty * item.salePrice, date: now,
      fromConsignment: csId
    });
    await GymDB.add('movements', {
      productId: item.productId, productName: item.productName,
      type: 'sale', quantity: -soldQty,
      notes: `Venta desde consignación #${csId} → Venta #${saleId}`, date: now
    });

    Utils.toast(`${soldQty} unidad(es) vendida(s)${remaining > 0 ? ` — ${remaining} quedan pendientes` : ''}`);
    manageClient(cs.clientId);
  };

  window.ConsignmentModule._markReturned = async (csId, idx) => {
    const cs = await GymDB.getById('consignments', csId);
    const item = cs.items[idx];
    item.status = 'devuelto';
    cs.updatedAt = new Date().toISOString();
    await GymDB.put('consignments', cs);
    await GymDB.updateStock(item.productId, item.quantity, 'return', `Devolución de consignación #${csId}`);
    Utils.toast('Producto devuelto al inventario');
    manageClient(cs.clientId);
  };

  const deleteConsignment = async (id) => {
    const ok = await Utils.confirm('¿Eliminar consignación? Los items pendientes NO se regresarán al inventario automáticamente.');
    if (!ok) return;
    await GymDB.remove('consignments', id);
    Utils.toast('Consignación eliminada', 'info');
    render();
  };

  // Elimina TODAS las consignaciones de un cliente (todas sus fechas).
  const deleteClientGroup = async (clientId) => {
    const all = await GymDB.getAll('consignments');
    const group = all.filter(c => c.clientId === clientId);
    if (!group.length) { render(); return; }
    const ok = await Utils.confirm(`¿Eliminar ${group.length > 1 ? `las ${group.length} consignaciones` : 'la consignación'} de este cliente (todas sus fechas)? Los items pendientes NO se regresarán al inventario automáticamente.`);
    if (!ok) return;
    for (const c of group) await GymDB.remove('consignments', c.id);
    Utils.toast(group.length > 1 ? 'Consignaciones eliminadas' : 'Consignación eliminada', 'info');
    render();
  };

  return { render, renderClients, addClient, editClient, deleteClient: deleteClient, newConsignment, manage, manageClient, ticket, delete: deleteConsignment, deleteClientGroup, _addItem: window.ConsignmentModule._addItem, _markSold: window.ConsignmentModule._markSold, _markReturned: window.ConsignmentModule._markReturned, _refreshCSTable: refreshCSTable };
})();
