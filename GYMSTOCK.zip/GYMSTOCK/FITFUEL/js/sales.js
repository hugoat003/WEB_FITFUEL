// GymStockPro — Sales Module
window.SalesModule = (() => {

  let cart = [];
  let allProducts = [];

  // ── Helpers ───────────────────────────────────────────────────
  const _getDiscountAmount = (subtotal) => {
    const type  = document.getElementById('disc-type')?.value || 'none';
    const value = parseFloat(document.getElementById('disc-value')?.value) || 0;
    if (type === 'none' || !value) return 0;
    if (type === 'pct')   return Math.min(subtotal * (value / 100), subtotal);
    if (type === 'fixed') return Math.min(value, subtotal);
    return 0;
  };

  // ── Render (list) ─────────────────────────────────────────────
  const render = async () => {
    const allSales = await GymDB.getAll('sales');
    allSales.sort((a, b) => new Date(b.date) - new Date(a.date));

    // Preserve filter state across re-renders
    const search   = document.getElementById('sale-search')?.value?.toLowerCase()  || '';
    const period   = document.getElementById('sale-period')?.value                  || 'all';
    const dateFrom = document.getElementById('sale-date-from')?.value               || '';
    const dateTo   = document.getElementById('sale-date-to')?.value                 || '';

    const now = new Date();
    let visible = allSales;

    if (period === 'today') {
      visible = visible.filter(s => new Date(s.date).toDateString() === now.toDateString());
    } else if (period === 'week') {
      const from = new Date(now); from.setDate(from.getDate() - 7);
      visible = visible.filter(s => new Date(s.date) >= from);
    } else if (period === 'month') {
      const from = new Date(now); from.setDate(from.getDate() - 30);
      visible = visible.filter(s => new Date(s.date) >= from);
    } else if (period === 'custom') {
      if (dateFrom) visible = visible.filter(s => s.date >= dateFrom);
      if (dateTo)   visible = visible.filter(s => s.date <= dateTo + 'T23:59:59');
    }

    if (search) {
      visible = visible.filter(s =>
        `${s.id}`.includes(search) ||
        s.items?.some(i => i.productName?.toLowerCase().includes(search)) ||
        s.type?.includes(search)
      );
    }

    const sales   = visible.filter(s => s.type !== 'return');
    const returns = visible.filter(s => s.type === 'return');

    const returnedBySaleId = {};
    returns.forEach(r => {
      returnedBySaleId[r.refSaleId] = (returnedBySaleId[r.refSaleId] || 0) + Math.abs(r.total);
    });

    const rows = sales.slice(0, 150).map(s => {
      const returnedAmount = returnedBySaleId[s.id] || 0;
      const hasReturn = returnedAmount > 0;
      const netTotal  = s.total - returnedAmount;
      const discTag   = s.discount?.amount > 0
        ? `<div style="font-size:11px;color:var(--red);margin-top:2px">−${Utils.currency(s.discount.amount)} desc</div>`
        : '';
      return [
        `<b>#${s.id}</b>`,
        Utils.datetime(s.date),
        Utils.statusBadge(s.type) + (hasReturn ? ' <span class="badge badge-warning">Devuelta</span>' : ''),
        s.items?.length || 0,
        hasReturn
          ? `<span style="text-decoration:line-through;color:var(--text-muted);font-size:12px">${Utils.currency(s.total)}</span> <b>${Utils.currency(netTotal)}</b>${discTag}`
          : `${Utils.currency(s.total)}${discTag}`,
        `<div class="action-btns">
          <button class="btn btn-sm btn-ghost" onclick="SalesModule.printSale(${s.id})">🖨 Comprobante</button>
          <button class="btn btn-sm btn-danger-ghost" onclick="SalesModule.returnSale(${s.id})">↩ Devolver</button>
        </div>`
      ];
    });

    const customVisible = period === 'custom' ? '' : 'display:none';

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Ventas</h1>
          <p class="page-sub">${sales.length} ventas${visible.length < allSales.length ? ` (${allSales.filter(s=>s.type!=='return').length} total)` : ' registradas'}</p>
        </div>
        <button class="btn btn-primary" onclick="SalesModule.newSale()">+ Nueva Venta</button>
      </div>

      <div class="toolbar">
        <input  id="sale-search" class="search-input" placeholder="🔍 ID, producto, tipo…"
                value="${search}" oninput="SalesModule.render()">
        <select id="sale-period" class="select-input" onchange="SalesModule.render()">
          <option value="all"    ${period==='all'    ?'selected':''}>Todos los períodos</option>
          <option value="today"  ${period==='today'  ?'selected':''}>Hoy</option>
          <option value="week"   ${period==='week'   ?'selected':''}>Últimos 7 días</option>
          <option value="month"  ${period==='month'  ?'selected':''}>Últimos 30 días</option>
          <option value="custom" ${period==='custom' ?'selected':''}>Personalizado…</option>
        </select>
        <input id="sale-date-from" type="date" class="select-input" value="${dateFrom}"
               style="${customVisible}" onchange="SalesModule.render()" title="Desde">
        <input id="sale-date-to"   type="date" class="select-input" value="${dateTo}"
               style="${customVisible}" onchange="SalesModule.render()" title="Hasta">
      </div>

      ${Utils.table(['#','Fecha','Tipo','Productos','Total','Acciones'], rows,
        { emptyMsg: 'No hay ventas para los filtros seleccionados' })}
    `;
  };

  // ── New sale flow ─────────────────────────────────────────────
  const newSale = async () => {
    allProducts = await GymDB.getAll('products');
    cart = [];
    await showSaleModal();
  };

  const showSaleModal = async () => {
    const clients = await GymDB.getAll('clients');
    const body = buildSaleBody(clients);
    const result = await Utils.modal('Nueva Venta', body, { wide: true, confirmLabel: 'Registrar Venta' });
    if (result !== 'confirm') return;
    await processSale();
  };

  const buildSaleBody = (clients) => {
    const productOpts = allProducts
      .filter(p => (p.stock || 0) > 0)
      .map(p => `<option value="${p.id}" data-price="${p.salePrice}" data-wholesale="${p.wholesalePrice||p.salePrice}" data-cost="${p.buyPrice||0}" data-stock="${p.stock}">${p.name} (Stock: ${p.stock})</option>`)
      .join('');

    const clientOpts = clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    const cartRows = cart.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.price)}</td>
        <td>${Utils.currency(item.quantity * item.price)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="SalesModule.removeCartItem(${i})">✕</button></td>
      </tr>`).join('');

    const subtotal = cart.reduce((s, i) => s + i.quantity * i.price, 0);

    return `
      <div class="form-grid">
        <div class="form-group">
          <label>Tipo de venta</label>
          <select id="sale-type" class="form-input" onchange="SalesModule.updateCartPrices()">
            <option value="retail">Público</option>
            <option value="wholesale">Mayoreo</option>
            <option value="cost">Costo (uso propio / regalo)</option>
          </select>
        </div>
        <div class="form-group">
          <label>Cliente (opcional)</label>
          <select id="sale-client" class="form-input">
            <option value="">— Sin cliente —</option>
            ${clientOpts}
          </select>
        </div>
      </div>

      <div class="form-group" style="margin-bottom:12px">
        <label>Descuento</label>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <select id="disc-type" class="form-input" style="flex:0 0 180px"
                  onchange="SalesModule.onDiscountTypeChange()">
            <option value="none">Sin descuento</option>
            <option value="pct">% Porcentaje</option>
            <option value="fixed">Monto fijo</option>
          </select>
          <input id="disc-value" type="number" class="form-input" min="0" step="0.01"
                 placeholder="0" style="flex:0 0 110px;display:none"
                 oninput="SalesModule.refreshCart()">
          <span id="disc-suffix" style="color:var(--text-muted);font-size:13px;display:none"></span>
        </div>
      </div>

      <div class="cart-add-row">
        <select id="sale-product" class="form-input" style="flex:2">${productOpts}</select>
        <input id="sale-qty" type="number" class="form-input" value="1" min="1" style="width:80px">
        <button class="btn btn-accent" onclick="SalesModule.addToCart()">+ Agregar</button>
      </div>
      <div class="cart-table" id="cart-table">
        ${cart.length ? `
          <table class="data-table">
            <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th><th></th></tr></thead>
            <tbody>${cartRows}</tbody>
          </table>
          <div class="cart-total">Total: <b>${Utils.currency(subtotal)}</b></div>
        ` : `<div class="empty-state" style="padding:20px"><span>🛒</span><p>Carrito vacío</p></div>`}
      </div>`;
  };

  window.SalesModule = window.SalesModule || {};

  window.SalesModule.onDiscountTypeChange = () => {
    const type   = document.getElementById('disc-type')?.value;
    const input  = document.getElementById('disc-value');
    const suffix = document.getElementById('disc-suffix');
    const show   = type !== 'none';
    if (input)  { input.style.display  = show ? '' : 'none'; if (!show) input.value = ''; }
    if (suffix) { suffix.style.display = show ? '' : 'none'; suffix.textContent = type === 'pct' ? '%' : (window.APP_CURRENCY || '$'); }
    refreshCart();
  };

  window.SalesModule.addToCart = async () => {
    const sel   = document.getElementById('sale-product');
    const pid   = parseInt(sel.value);
    const qty   = parseInt(document.getElementById('sale-qty').value) || 1;
    const type  = document.getElementById('sale-type').value;
    const opt   = sel.options[sel.selectedIndex];
    const stock = parseInt(opt.dataset.stock);
    if (qty > stock) { Utils.toast(`Solo hay ${stock} en stock`, 'error'); return; }
    const price = type === 'wholesale'
      ? parseFloat(opt.dataset.wholesale)
      : type === 'cost'
        ? parseFloat(opt.dataset.cost)
        : parseFloat(opt.dataset.price);
    const existing = cart.find(i => i.productId === pid);
    if (existing) {
      if (existing.quantity + qty > stock) { Utils.toast('Stock insuficiente', 'error'); return; }
      existing.quantity += qty;
    } else {
      cart.push({ productId: pid, productName: opt.text.split(' (Stock')[0], quantity: qty, price });
    }
    refreshCart();
  };

  window.SalesModule.removeCartItem = (i) => {
    cart.splice(i, 1);
    refreshCart();
  };

  window.SalesModule.updateCartPrices = () => {
    const type = document.getElementById('sale-type').value;
    cart.forEach(item => {
      const p = allProducts.find(p => p.id === item.productId);
      if (p) {
        if (type === 'wholesale') item.price = p.wholesalePrice || p.salePrice;
        else if (type === 'cost') item.price = p.buyPrice || 0;
        else item.price = p.salePrice;
      }
    });
    refreshCart();
  };

  const refreshCart = () => {
    const cartRows = cart.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.price)}</td>
        <td>${Utils.currency(item.quantity * item.price)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="SalesModule.removeCartItem(${i})">✕</button></td>
      </tr>`).join('');

    const subtotal   = cart.reduce((s, i) => s + i.quantity * i.price, 0);
    const discAmount = _getDiscountAmount(subtotal);
    const total      = subtotal - discAmount;

    const container = document.getElementById('cart-table');
    if (!container) return;
    container.innerHTML = cart.length ? `
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>${cartRows}</tbody>
      </table>
      <div class="cart-total">
        ${discAmount > 0 ? `
          <span style="color:var(--text-muted);font-size:13px">Subtotal: ${Utils.currency(subtotal)}</span><br>
          <span style="color:var(--red);font-size:13px">Descuento: −${Utils.currency(discAmount)}</span><br>
        ` : ''}
        Total: <b>${Utils.currency(total)}</b>
      </div>
    ` : `<div class="empty-state" style="padding:20px"><span>🛒</span><p>Carrito vacío</p></div>`;
  };

  // Expose refreshCart for onDiscountTypeChange
  window.SalesModule.refreshCart = refreshCart;

  const processSale = async () => {
    if (!cart.length) { Utils.toast('El carrito está vacío', 'error'); return; }

    const type     = Utils.val('sale-type');
    const clientId = Utils.val('sale-client') ? parseInt(Utils.val('sale-client')) : null;
    const subtotal = cart.reduce((s, i) => s + i.quantity * i.price, 0);

    const discType  = document.getElementById('disc-type')?.value || 'none';
    const discValue = parseFloat(document.getElementById('disc-value')?.value) || 0;
    let discAmount  = 0;
    if (discType === 'pct')   discAmount = Math.min(subtotal * (discValue / 100), subtotal);
    if (discType === 'fixed') discAmount = Math.min(discValue, subtotal);
    const total    = subtotal - discAmount;
    const discount = discAmount > 0 ? { type: discType, value: discValue, amount: discAmount } : null;

    const now    = new Date().toISOString();
    const saleId = await GymDB.add('sales', { type, clientId, items: cart, subtotal, discount, total, date: now });

    for (const item of cart) {
      await GymDB.updateStock(item.productId, -item.quantity, 'sale', `Venta #${saleId}`);
    }

    const sale = await GymDB.getById('sales', saleId);
    let clientName = '';
    if (clientId) { const c = await GymDB.getById('clients', clientId); clientName = c?.name || ''; }

    Utils.toast(`Venta registrada — ${Utils.currency(total)}`);
    Utils.printReceipt(sale, cart, clientName);
    render();
  };

  const printSale = async (id) => {
    const sale = await GymDB.getById('sales', id);
    let clientName = '';
    if (sale.clientId) { const c = await GymDB.getById('clients', sale.clientId); clientName = c?.name || ''; }
    Utils.printReceipt(sale, sale.items, clientName);
  };

  const returnSale = async (id) => {
    const sale = await GymDB.getById('sales', id);
    if (!sale) { Utils.toast('Venta no encontrada', 'error'); return; }

    const allSales = await GymDB.getAll('sales');
    const prevReturns = allSales.filter(s => s.type === 'return' && s.refSaleId === id);
    const alreadyReturned = {};
    prevReturns.forEach(r => r.items.forEach(i => {
      alreadyReturned[i.productId] = (alreadyReturned[i.productId] || 0) + i.quantity;
    }));

    const returnableItems = sale.items.filter(i => {
      return i.quantity - (alreadyReturned[i.productId] || 0) > 0;
    });
    if (!returnableItems.length) { Utils.toast('Esta venta ya fue devuelta completamente', 'error'); return; }

    const itemRows = returnableItems.map(item => {
      const returned = alreadyReturned[item.productId] || 0;
      const maxQty   = item.quantity - returned;
      return `
        <tr>
          <td>${item.productName}</td>
          <td>${item.quantity}${returned ? ` <small>(${returned} ya devueltos)</small>` : ''}</td>
          <td>${Utils.currency(item.price)}</td>
          <td>
            <input type="number" class="form-input return-qty"
              data-product-id="${item.productId}" data-product-name="${item.productName}"
              data-price="${item.price}" data-max="${maxQty}"
              value="0" min="0" max="${maxQty}" style="width:70px">
          </td>
        </tr>`;
    }).join('');

    const body = `
      <p style="margin-bottom:12px;color:var(--text-2)">Venta <b>#${id}</b> — ${Utils.datetime(sale.date)}</p>
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Vendido</th><th>Precio</th><th>Devolver</th></tr></thead>
        <tbody>${itemRows}</tbody>
      </table>
      <div class="form-group" style="margin-top:16px">
        <label>Motivo (opcional)</label>
        <input id="return-notes" type="text" class="form-input" placeholder="Ej: Producto defectuoso">
      </div>`;

    const result = await Utils.modal('Devolución de Venta', body, { wide: true, confirmLabel: 'Confirmar Devolución' });
    if (result !== 'confirm') return;

    const notes = document.getElementById('return-notes')?.value || '';
    const returnItems = [];
    document.querySelectorAll('.return-qty').forEach(input => {
      const qty = parseInt(input.value) || 0;
      if (qty > 0) returnItems.push({
        productId: parseInt(input.dataset.productId),
        productName: input.dataset.productName,
        quantity: qty,
        price: parseFloat(input.dataset.price)
      });
    });

    if (!returnItems.length) { Utils.toast('Ingresa al menos una cantidad a devolver', 'error'); return; }
    const overLimit = returnItems.find(i => {
      const input = document.querySelector(`.return-qty[data-product-id="${i.productId}"]`);
      return i.quantity > parseInt(input?.dataset.max || 0);
    });
    if (overLimit) { Utils.toast('Cantidad excede el máximo devolvible', 'error'); return; }

    const refundTotal = returnItems.reduce((s, i) => s + i.quantity * i.price, 0);
    const now = new Date().toISOString();

    await GymDB.add('sales', { type: 'return', refSaleId: id, clientId: sale.clientId, items: returnItems, total: -refundTotal, notes, date: now });
    for (const item of returnItems) {
      await GymDB.updateStock(item.productId, item.quantity, 'return', `Devolución Venta #${id}${notes ? ' — ' + notes : ''}`);
    }

    Utils.toast(`Devolución registrada — reembolso ${Utils.currency(refundTotal)}`);
    render();
  };

  window.SalesModule.returnSale = returnSale;

  return {
    render, newSale, printSale, returnSale,
    addToCart: window.SalesModule.addToCart,
    removeCartItem: window.SalesModule.removeCartItem,
    updateCartPrices: window.SalesModule.updateCartPrices,
    onDiscountTypeChange: window.SalesModule.onDiscountTypeChange,
    refreshCart
  };
})();
