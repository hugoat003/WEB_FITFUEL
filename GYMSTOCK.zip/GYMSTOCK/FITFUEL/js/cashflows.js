// GymStockPro — Cash Flow Module
window.CashflowsModule = (() => {

  const INCOME_CATS  = ['Inversión propia', 'Préstamo recibido', 'Venta externa', 'Servicio prestado', 'Devolución proveedor', 'Otro ingreso'];
  const EXPENSE_CATS = ['Alquiler', 'Servicios básicos', 'Transporte', 'Marketing/publicidad', 'Compra extra', 'Gastos de personal', 'Gastos varios'];

  let _filter = 'all'; // 'all' | 'income' | 'expense'

  const render = async () => {
    const flows = await GymDB.getAll('cashflows');
    flows.sort((a, b) => new Date(b.date) - new Date(a.date));

    const incomes  = flows.filter(f => f.type === 'income');
    const expenses = flows.filter(f => f.type === 'expense');
    const totalIn  = incomes.reduce((s, f) => s + f.amount, 0);
    const totalOut = expenses.reduce((s, f) => s + f.amount, 0);
    const balance  = totalIn - totalOut;

    const visible = _filter === 'income' ? incomes : _filter === 'expense' ? expenses : flows;

    const rows = visible.map(f => [
      Utils.date(f.date),
      f.type === 'income'
        ? `<span class="badge badge-ok">↑ Ingreso</span>`
        : `<span class="badge badge-danger">↓ Egreso</span>`,
      f.category,
      f.description,
      `<span style="color:${f.type === 'income' ? 'var(--green)' : 'var(--red)'};font-weight:600">${f.type === 'income' ? '+' : '−'}${Utils.currency(f.amount)}</span>`,
      f.notes || '—',
      `<div class="action-btns">
        <button class="btn btn-sm btn-ghost" onclick="CashflowsModule.editFlow(${f.id})">✏ Editar</button>
        <button class="btn btn-sm btn-danger-ghost" onclick="CashflowsModule.deleteFlow(${f.id})">✕</button>
      </div>`
    ]);

    const filterBtns = ['all', 'income', 'expense'].map(f => {
      const labels = { all: 'Todos', income: 'Ingresos', expense: 'Egresos' };
      return `<button class="btn btn-sm ${_filter === f ? 'btn-primary' : 'btn-ghost'}" onclick="CashflowsModule.setFilter('${f}')">${labels[f]}</button>`;
    }).join('');

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Flujo de Caja</h1>
          <p class="page-sub">${flows.length} movimientos registrados</p>
        </div>
        <button class="btn btn-primary" onclick="CashflowsModule.newFlow()">+ Nuevo Movimiento</button>
      </div>

      <div class="pnl-strip">
        <div class="pnl-item">
          <div class="pnl-label">Total Ingresos</div>
          <div class="pnl-value income">${Utils.currency(totalIn)}</div>
          <div class="pnl-margin">${incomes.length} entradas</div>
        </div>
        <div class="pnl-divider">−</div>
        <div class="pnl-item">
          <div class="pnl-label">Total Egresos</div>
          <div class="pnl-value cost">${Utils.currency(totalOut)}</div>
          <div class="pnl-margin">${expenses.length} salidas</div>
        </div>
        <div class="pnl-divider">=</div>
        <div class="pnl-item highlight">
          <div class="pnl-label">Balance neto</div>
          <div class="pnl-value profit ${balance < 0 ? 'negative' : ''}">${Utils.currency(balance)}</div>
          <div class="pnl-margin">${balance >= 0 ? 'positivo' : 'negativo'}</div>
        </div>
      </div>

      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <span style="font-size:13px;color:var(--text-muted)">Filtrar:</span>
        ${filterBtns}
      </div>

      ${Utils.table(
        ['Fecha', 'Tipo', 'Categoría', 'Descripción', 'Monto', 'Notas', 'Acciones'],
        rows,
        { emptyMsg: 'No hay movimientos registrados' }
      )}
    `;
  };

  const _buildForm = (data = {}) => `
    <div class="form-grid">
      <div class="form-group">
        <label>Tipo *</label>
        <select id="cf-type" class="form-input" onchange="CashflowsModule.updateCategories()">
          <option value="income"  ${data.type === 'income'  ? 'selected' : ''}>↑ Ingreso</option>
          <option value="expense" ${data.type === 'expense' ? 'selected' : ''}>↓ Egreso</option>
        </select>
      </div>
      <div class="form-group">
        <label>Categoría *</label>
        <select id="cf-category" class="form-input">
          ${(data.type === 'expense' ? EXPENSE_CATS : INCOME_CATS).map(c =>
            `<option ${c === data.category ? 'selected' : ''}>${c}</option>`
          ).join('')}
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Descripción *</label>
      <input id="cf-description" type="text" class="form-input" placeholder="Ej: Pago renta local" value="${data.description || ''}">
    </div>
    <div class="form-grid">
      <div class="form-group">
        <label>Monto *</label>
        <input id="cf-amount" type="number" class="form-input" min="0.01" step="0.01" placeholder="0.00" value="${data.amount || ''}">
      </div>
      <div class="form-group">
        <label>Fecha</label>
        <input id="cf-date" type="date" class="form-input" value="${data.date ? data.date.slice(0, 10) : new Date().toISOString().slice(0, 10)}">
      </div>
    </div>
    <div class="form-group">
      <label>Notas</label>
      <input id="cf-notes" type="text" class="form-input" placeholder="Opcional" value="${data.notes || ''}">
    </div>
  `;

  const _readForm = () => {
    const description = Utils.val('cf-description');
    const amount      = Utils.numVal('cf-amount');
    if (!description) { Utils.toast('Ingresa una descripción', 'error'); return null; }
    if (!amount || amount <= 0) { Utils.toast('Ingresa un monto válido', 'error'); return null; }
    const dateStr = document.getElementById('cf-date').value;
    return {
      type        : Utils.val('cf-type'),
      category    : Utils.val('cf-category'),
      description,
      amount,
      notes       : Utils.val('cf-notes'),
      date        : dateStr ? (dateStr + 'T12:00:00') : new Date().toISOString(),
    };
  };

  const newFlow = async () => {
    const result = await Utils.modal('Nuevo Movimiento de Caja', _buildForm(), { confirmLabel: 'Registrar' });
    if (result !== 'confirm') return;
    const data = _readForm();
    if (!data) return;
    await GymDB.add('cashflows', data);
    Utils.toast('Movimiento registrado');
    render();
  };

  const editFlow = async (id) => {
    const existing = await GymDB.getById('cashflows', id);
    if (!existing) return;
    const result = await Utils.modal('Editar Movimiento', _buildForm(existing), { confirmLabel: 'Guardar cambios' });
    if (result !== 'confirm') return;
    const data = _readForm();
    if (!data) return;
    await GymDB.put('cashflows', { ...existing, ...data });
    Utils.toast('Movimiento actualizado');
    render();
  };

  const deleteFlow = async (id) => {
    const ok = await Utils.confirm('¿Eliminar este movimiento? Esta acción no se puede deshacer.');
    if (!ok) return;
    await GymDB.remove('cashflows', id);
    Utils.toast('Movimiento eliminado', 'info');
    render();
  };

  const setFilter = (f) => { _filter = f; render(); };

  // Exposed for inline onchange
  window.CashflowsModule = window.CashflowsModule || {};
  window.CashflowsModule.updateCategories = () => {
    const type = document.getElementById('cf-type')?.value;
    const cats = type === 'expense' ? EXPENSE_CATS : INCOME_CATS;
    const sel  = document.getElementById('cf-category');
    if (sel) sel.innerHTML = cats.map(c => `<option>${c}</option>`).join('');
  };
  window.CashflowsModule.deleteFlow = deleteFlow;
  window.CashflowsModule.editFlow   = editFlow;
  window.CashflowsModule.setFilter  = setFilter;

  return { render, newFlow, editFlow, deleteFlow, setFilter,
           updateCategories: window.CashflowsModule.updateCategories };
})();
