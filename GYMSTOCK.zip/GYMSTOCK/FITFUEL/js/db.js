// GymStockPro — Capa de datos (respaldada por el servidor)
//
// Antes los datos vivian en IndexedDB, es decir, dentro de UN navegador.
// Ahora viven en el servidor (data/gymstock.json) para que la PC y el
// celular compartan la misma informacion. La API publica de GymDB no
// cambio, asi que el resto de los modulos siguen funcionando igual.
//
// El IndexedDB viejo NO se borra: se usa como origen de la migracion
// inicial y se conserva como respaldo.

const DB_NAME = 'GymStockPro';
const CACHE_DB = 'GymStockProCache';

window.GymDB = (() => {
  const STORES = ['products', 'movements', 'sales', 'consignments',
                  'clients', 'suppliers', 'purchases', 'settings', 'cashflows'];
  const keyOf = (store) => (store === 'settings' ? 'key' : 'id');

  let mem = null;          // { store: Map(key -> value) }
  let rev = 0;
  let offline = false;
  const listeners = [];

  const emit = (event, detail) => listeners.forEach(fn => {
    try { fn(event, detail); } catch (_) {}
  });

  // ── HTTP ────────────────────────────────────────────────────────
  class AuthError extends Error {
    constructor() { super('PIN requerido'); this.code = 'NEEDS_PIN'; }
  }
  class OfflineError extends Error {
    constructor() { super('Sin conexion con el servidor'); this.code = 'OFFLINE'; }
  }

  const request = async (path, body) => {
    let res;
    try {
      res = await fetch(path, body === undefined ? { credentials: 'same-origin' } : {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
    } catch (_) {
      offline = true;
      emit('connection', { online: false });
      throw new OfflineError();
    }
    if (res.status === 401) { emit('auth-required'); throw new AuthError(); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
    if (offline) { offline = false; emit('connection', { online: true }); }
    return data;
  };

  // ── Cache local (solo lectura sin conexion) ─────────────────────
  // Base separada: nunca tocamos la original.
  const cacheDB = () => new Promise((resolve, reject) => {
    const req = indexedDB.open(CACHE_DB, 1);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains('snapshot')) d.createObjectStore('snapshot');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  const cacheSave = async () => {
    try {
      const d = await cacheDB();
      const snap = { rev, stores: {} };
      for (const s of STORES) snap.stores[s] = [...mem[s].values()];
      await new Promise((res, rej) => {
        const t = d.transaction('snapshot', 'readwrite').objectStore('snapshot').put(snap, 'state');
        t.onsuccess = res; t.onerror = () => rej(t.error);
      });
    } catch (_) { /* el cache es opcional */ }
  };

  const cacheLoad = async () => {
    try {
      const d = await cacheDB();
      return await new Promise((res, rej) => {
        const t = d.transaction('snapshot').objectStore('snapshot').get('state');
        t.onsuccess = () => res(t.result || null); t.onerror = () => rej(t.error);
      });
    } catch (_) { return null; }
  };

  // ── Estado en memoria ───────────────────────────────────────────
  const load = (snapshot) => {
    mem = {};
    for (const s of STORES) {
      mem[s] = new Map();
      for (const item of snapshot.stores[s] || []) {
        mem[s].set(String(item[keyOf(s)]), item);
      }
    }
    rev = snapshot.rev || 0;
  };

  // ── Migracion desde el IndexedDB del navegador ──────────────────
  const readLegacy = () => new Promise((resolve) => {
    let req;
    try { req = indexedDB.open(DB_NAME); } catch (_) { return resolve(null); }
    req.onerror = () => resolve(null);
    req.onsuccess = async () => {
      const d = req.result;
      const present = STORES.filter(s => d.objectStoreNames.contains(s));
      if (!present.length) { d.close(); return resolve(null); }
      const out = {};
      try {
        for (const s of present) {
          out[s] = await new Promise((res, rej) => {
            const r = d.transaction(s).objectStore(s).getAll();
            r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error);
          });
        }
      } catch (_) { d.close(); return resolve(null); }
      d.close();
      resolve(out);
    };
  });

  const migrateIfNeeded = async () => {
    const legacy = await readLegacy();
    if (!legacy) return false;
    const total = STORES.filter(s => s !== 'settings')
      .reduce((n, s) => n + (legacy[s]?.length || 0), 0);
    if (total === 0) return false;

    emit('migrating', { total });
    const result = await request('/api/seed', { stores: legacy });
    if (!result.seeded) return false;
    const fresh = await request('/api/state');
    load(fresh);
    emit('migrated', { total });
    return true;
  };

  // ── Ciclo de vida ───────────────────────────────────────────────
  const init = async () => {
    const session = await request('/api/session');
    if (!session.authorized) throw new AuthError();

    let snapshot;
    try {
      snapshot = await request('/api/state');
    } catch (err) {
      if (err.code !== 'OFFLINE') throw err;
      const cached = await cacheLoad();
      if (!cached) throw err;
      load(cached);
      emit('connection', { online: false });
      return { offline: true };
    }

    load(snapshot);
    if (!session.hasData) {
      try { await migrateIfNeeded(); }
      catch (err) { console.warn('Migracion no realizada:', err); }
    }
    await cacheSave();
    return { offline: false };
  };

  /** Trae cambios hechos desde otro dispositivo. Devuelve true si hubo. */
  const pull = async () => {
    const { rev: serverRev } = await request('/api/rev');
    if (serverRev === rev) return false;
    load(await request('/api/state'));
    await cacheSave();
    emit('remote-change', { rev });
    return true;
  };

  // ── Escrituras ──────────────────────────────────────────────────
  const applyLocal = (op, result) => {
    if (op.op === 'updateStock') {
      mem.products.set(String(result.product.id), result.product);
      mem.movements.set(String(result.movement.id), result.movement);
      return;
    }
    const k = keyOf(op.store);
    if (op.op === 'delete') mem[op.store].delete(String(op.id));
    else {
      const value = { ...op.value, [k]: op.value[k] ?? result };
      mem[op.store].set(String(value[k]), value);
    }
  };

  const mutate = async (ops) => {
    if (offline) throw new OfflineError();
    const res = await request('/api/mutate', { ops });
    ops.forEach((op, i) => applyLocal(op, res.results[i]));
    rev = res.rev;
    cacheSave();
    return res.results;
  };

  const add = async (store, data) => (await mutate([{ store, op: 'add', value: data }]))[0];
  const put = async (store, data) => (await mutate([{ store, op: 'put', value: data }]))[0];
  const remove = async (store, id) => { await mutate([{ store, op: 'delete', id }]); };

  /** Escritura masiva en una sola llamada (importar respaldo). */
  const bulkPut = async (store, items) =>
    items.length ? mutate(items.map(value => ({ store, op: 'put', value }))) : [];

  const bulkRemove = async (store, ids) =>
    ids.length ? mutate(ids.map(id => ({ store, op: 'delete', id }))) : [];

  const updateStock = async (productId, delta, movementType, notes = '') => {
    const [res] = await mutate([{ op: 'updateStock', productId, delta, movementType, notes }]);
    return res.product;
  };

  // ── Lecturas (sincronas por debajo, mantienen la firma Promise) ──
  const getAll = async (store) => [...mem[store].values()];
  const getById = async (store, id) => mem[store].get(String(id));
  const getByIndex = async (store, field, value) =>
    [...mem[store].values()].filter(x => x[field] === value);
  const getSetting = async (key) => {
    const rec = mem.settings.get(String(key));
    return rec ? rec.value : null;
  };
  const setSetting = (key, value) => put('settings', { key, value });

  // ── Estado de conexion ──────────────────────────────────────────
  const isOffline = () => offline;
  const onChange = (fn) => listeners.push(fn);

  return {
    init, pull, onChange, isOffline,
    getAll, getById, getByIndex, getSetting, setSetting,
    add, put, remove, bulkPut, bulkRemove, updateStock,
    STORES,
  };
})();
