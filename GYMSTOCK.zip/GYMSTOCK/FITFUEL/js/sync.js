// GymStockPro — Arranque, PIN de acceso remoto y sincronizacion entre dispositivos.

window.Sync = (() => {
  const POLL_MS = 6000;
  let polling = null;
  let booted = false;

  // ── Pantalla de PIN ─────────────────────────────────────────────
  const showPinScreen = () => new Promise((resolve) => {
    const el = document.getElementById('pin-screen');
    el.classList.add('open');
    document.getElementById('loading-screen').style.display = 'none';

    const input = document.getElementById('pin-input');
    const error = document.getElementById('pin-error');
    const button = document.getElementById('pin-submit');

    const submit = async () => {
      const pin = input.value.trim();
      if (!pin) return;
      button.disabled = true;
      error.textContent = '';
      try {
        const res = await fetch('/api/login', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          error.textContent = data.error || 'No se pudo entrar';
          input.value = '';
          input.focus();
          return;
        }
        el.classList.remove('open');
        resolve();
      } catch (_) {
        error.textContent = 'Sin conexion con el servidor';
      } finally {
        button.disabled = false;
      }
    };

    button.onclick = submit;
    input.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
    setTimeout(() => input.focus(), 120);
  });

  // ── Indicador de conexion ───────────────────────────────────────
  const setStatus = (state, text) => {
    const pill = document.getElementById('sync-pill');
    if (!pill) return;
    pill.className = `sync-pill ${state}`;
    pill.textContent = text;
    pill.style.display = state === 'ok' ? 'none' : 'flex';
  };

  // ── Sincronizacion periodica ────────────────────────────────────
  const tick = async () => {
    if (document.hidden) return;
    try {
      const changed = await GymDB.pull();
      if (changed && window.App?.reload) App.reload();
      setStatus('ok', '');
    } catch (err) {
      if (err.code === 'OFFLINE') setStatus('offline', '⚠ Sin conexion — solo lectura');
      else if (err.code === 'NEEDS_PIN') { /* lo maneja el listener de auth */ }
    }
  };

  const startPolling = () => {
    if (polling) return;
    polling = setInterval(tick, POLL_MS);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); });
    window.addEventListener('online', tick);
  };

  // ── Arranque ────────────────────────────────────────────────────
  const fail = (message, hint = '') => {
    document.getElementById('loading-screen').style.display = 'flex';
    document.getElementById('loading-screen').innerHTML = `
      <div style="color:#ef4444;font-size:16px;text-align:center;padding:24px;max-width:420px">
        <div style="font-size:40px;margin-bottom:12px">⚠️</div>
        <b>Error al iniciar</b>
        <div style="margin-top:8px;font-size:14px;color:#94a3b8;line-height:1.5">${message}</div>
        ${hint ? `<div style="margin-top:12px;font-size:13px;color:#64748b">${hint}</div>` : ''}
      </div>`;
  };

  const boot = async () => {
    GymDB.onChange((event, detail) => {
      if (event === 'connection') {
        setStatus(detail.online ? 'ok' : 'offline',
                  detail.online ? '' : '⚠ Sin conexion — solo lectura');
      }
      if (event === 'migrating') {
        const sub = document.querySelector('.loading-sub');
        if (sub) sub.textContent = `Migrando ${detail.total} registros al servidor…`;
      }
      if (event === 'migrated') {
        setTimeout(() => Utils.toast(
          `Migracion lista: ${detail.total} registros ahora viven en el servidor`), 900);
      }
      if (event === 'auth-required' && booted) {
        stopAndRelogin();
      }
    });

    for (;;) {
      try {
        await GymDB.init();
        break;
      } catch (err) {
        if (err.code === 'NEEDS_PIN') { await showPinScreen(); continue; }
        if (err.code === 'OFFLINE') {
          return fail('No se pudo contactar al servidor.',
                      'Verifica que el servidor este corriendo en la computadora.');
        }
        return fail(err.message || String(err));
      }
    }

    document.getElementById('pin-screen').classList.remove('open');
    await App.init();
    booted = true;
    if (GymDB.isOffline()) setStatus('offline', '⚠ Sin conexion — solo lectura');
    startPolling();
  };

  const stopAndRelogin = async () => {
    if (polling) { clearInterval(polling); polling = null; }
    booted = false;
    await showPinScreen();
    await GymDB.init();
    App.reload();
    booted = true;
    startPolling();
  };

  return { boot, setStatus };
})();
