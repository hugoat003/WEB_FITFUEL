// GymStockPro — Utilities, Modal, Toast, Formatters

window.Utils = (() => {

  // ── Formatters ────────────────────────────────────────────────
  const currency = (n) => {
    const sym = window.APP_CURRENCY || '$';
    return `${sym}${parseFloat(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };
  const date = (iso) => iso ? new Date(iso).toLocaleDateString('es-MX', { day:'2-digit', month:'short', year:'numeric' }) : '—';
  const datetime = (iso) => iso ? new Date(iso).toLocaleString('es-MX', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—';
  const pct = (n) => `${parseFloat(n || 0).toFixed(1)}%`;
  const margin = (buy, sell) => sell > 0 ? ((sell - buy) / sell * 100) : 0;

  // ── Toast notifications ───────────────────────────────────────
  const toast = (msg, type = 'success') => {
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span class="toast-icon">${type==='success'?'✓':type==='error'?'✕':'ℹ'}</span><span>${msg}</span>`;
    document.getElementById('toast-container').appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
  };

  // ── Modal ─────────────────────────────────────────────────────
  let _modalResolve = null;

  const modal = (title, bodyHTML, opts = {}) => new Promise((resolve) => {
    _modalResolve = resolve;
    const m = document.getElementById('app-modal');
    const mTitle = document.getElementById('modal-title');
    const mBody = document.getElementById('modal-body');
    const mFooter = document.getElementById('modal-footer');

    mTitle.textContent = title;
    mBody.innerHTML = bodyHTML;
    mFooter.innerHTML = '';

    const buttons = opts.buttons || [
      { label: opts.confirmLabel || 'Guardar', cls: 'btn-primary', value: 'confirm' },
      { label: 'Cancelar', cls: 'btn-ghost', value: 'cancel' }
    ];
    buttons.forEach(b => {
      const btn = document.createElement('button');
      btn.className = `btn ${b.cls}`;
      btn.textContent = b.label;
      btn.onclick = () => closeModal(b.value);
      mFooter.appendChild(btn);
    });

    if (opts.wide) m.querySelector('.modal-box').classList.add('modal-wide');
    else m.querySelector('.modal-box').classList.remove('modal-wide');

    m.classList.add('open');

    // Auto-focus first input
    setTimeout(() => {
      const first = mBody.querySelector('input, select, textarea');
      if (first) first.focus();
    }, 80);
  });

  const closeModal = (value) => {
    document.getElementById('app-modal').classList.remove('open');
    if (_modalResolve) { _modalResolve(value); _modalResolve = null; }
  };

  const confirm = (msg) => modal('Confirmar', `<p class="confirm-msg">${msg}</p>`, {
    buttons: [
      { label: 'Confirmar', cls: 'btn-danger', value: 'confirm' },
      { label: 'Cancelar', cls: 'btn-ghost', value: 'cancel' }
    ]
  }).then(v => v === 'confirm');

  // ── Form helpers ──────────────────────────────────────────────
  const val = (id) => document.getElementById(id)?.value?.trim() || '';
  const numVal = (id) => parseFloat(document.getElementById(id)?.value) || 0;
  const setVal = (id, v) => { const el = document.getElementById(id); if (el) el.value = v ?? ''; };

  const formData = (ids) => {
    const obj = {};
    ids.forEach(id => { obj[id] = val(id); });
    return obj;
  };

  // ── Table builder ─────────────────────────────────────────────
  // Cada celda lleva data-label con el nombre de su columna: en pantallas
  // chicas el CSS oculta el encabezado y usa esa etiqueta para dibujar
  // cada fila como una tarjeta legible.
  //
  // opts.scroll = true conserva la tabla real en el celular y se navega
  // deslizando de lado, con la primera columna fija.
  const attr = (s) => String(s ?? '').replace(/<[^>]*>/g, '').replace(/"/g, '&quot;').trim();

  const table = (cols, rows, opts = {}) => {
    if (!rows.length) return `<div class="empty-state"><span>📭</span><p>${opts.emptyMsg || 'Sin registros'}</p></div>`;
    return `
      <div class="table-wrap${opts.scroll ? ' table-scroll' : ''}">
        <table class="data-table">
          <thead><tr>${cols.map(c => `<th>${c}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map((c, i) =>
            `<td data-label="${attr(cols[i])}">${c ?? '—'}</td>`).join('')}</tr>`).join('')}</tbody>
        </table>
      </div>`;
  };

  // ── Stock badge ───────────────────────────────────────────────
  const stockBadge = (stock, min) => {
    if (stock <= 0) return `<span class="badge badge-danger">Sin stock</span>`;
    if (stock <= min) return `<span class="badge badge-warning">⚠ Bajo</span>`;
    return `<span class="badge badge-ok">OK</span>`;
  };

  const statusBadge = (status) => {
    const map = {
      pendiente: ['badge-warning', '⏳ Pendiente'],
      vendido: ['badge-ok', '✓ Vendido'],
      devuelto: ['badge-info', '↩ Devuelto'],
      retail: ['badge-info', 'Público'],
      wholesale: ['badge-purple', 'Mayoreo'],
      cost: ['badge-ghost', '🏷 Costo'],
    };
    const [cls, label] = map[status] || ['badge-ghost', status];
    return `<span class="badge ${cls}">${label}</span>`;
  };

  // ── Category options ─────────────────────────────────────────
  const CATEGORIES = ['Proteína', 'Creatina', 'Pre-entreno', 'Aminoácidos', 'Quemadores', 'Vitaminas', 'Ganadores de peso', 'Barras proteicas', 'Rehidratantes', 'Otro'];

  const categoryOpts = (selected = '') =>
    CATEGORIES.map(c => `<option value="${c}" ${c===selected?'selected':''}>${c}</option>`).join('');

  // ── Receipt generator ─────────────────────────────────────────
  const printReceipt = (sale, items, clientName = '') => {
    const storeName = window.APP_STORE || 'GymStockPro';
    const lines = items.map(i => `
      <tr>
        <td>${i.productName}</td>
        <td style="text-align:center">${i.quantity}</td>
        <td style="text-align:right">${currency(i.price)}</td>
        <td style="text-align:right">${currency(i.quantity * i.price)}</td>
      </tr>`).join('');

    const w = window.open('', '_blank', 'width=420,height=600');
    w.document.write(`
      <!DOCTYPE html><html><head>
      <meta charset="UTF-8"><title>Comprobante</title>
      <style>
        body{font-family:monospace;padding:20px;font-size:13px;max-width:380px;margin:0 auto}
        h2{text-align:center;font-size:16px;margin:0}
        .sub{text-align:center;color:#666;margin-bottom:16px;font-size:12px}
        table{width:100%;border-collapse:collapse}
        th{border-bottom:2px solid #000;padding:4px 2px;font-size:11px}
        td{padding:4px 2px;border-bottom:1px dotted #ccc;font-size:12px}
        .total{font-weight:bold;font-size:15px;text-align:right;margin-top:12px;padding-top:8px;border-top:2px solid #000}
        .footer{text-align:center;margin-top:16px;font-size:11px;color:#888}
        @media print{button{display:none}}
      </style></head><body>
      <h2>${storeName}</h2>
      <div class="sub">Comprobante de venta<br>${datetime(sale.date)}</div>
      ${clientName ? `<p style="font-size:12px">Cliente: <b>${clientName}</b></p>` : ''}
      <p style="font-size:12px">Tipo: <b>${sale.type === 'wholesale' ? 'Mayoreo' : sale.type === 'cost' ? 'Costo/Regalo' : 'Público'}</b> &nbsp; #${sale.id}</p>
      <table>
        <thead><tr><th>Producto</th><th>Cant.</th><th>P.Unit</th><th>Total</th></tr></thead>
        <tbody>${lines}</tbody>
      </table>
      ${sale.discount?.amount > 0 ? `
        <div style="text-align:right;margin-top:10px;padding-top:6px;border-top:1px dotted #ccc;font-size:13px">
          Subtotal: ${currency(sale.subtotal || sale.total)}<br>
          Descuento${sale.discount.type==='pct' ? ` (${sale.discount.value}%)` : ''}: −${currency(sale.discount.amount)}
        </div>` : ''}
      <div class="total">TOTAL: ${currency(sale.total)}</div>
      <div class="footer">¡Gracias por su compra!</div>
      <br><button onclick="window.print()">🖨 Imprimir</button>
      </body></html>`);
    w.document.close();
  };

  // ── Simple bar chart ─────────────────────────────────────────
  const barChart = (data, opts = {}) => {
    if (!data.length) return '<div class="empty-state"><span>📊</span><p>Sin datos</p></div>';
    const max = Math.max(...data.map(d => d.value), 1);
    const h = opts.height || 180;
    const bars = data.map(d => {
      const pct = (d.value / max) * 100;
      const tooltipText = d.tooltip
        ? `${d.tooltip}<br><span style="opacity:.75;font-size:11px">${opts.currency ? currency(d.value) : d.value + ' uds'}</span>`
        : null;
      return `
        <div class="bar-item">
          ${tooltipText ? `<div class="bar-tooltip">${tooltipText}</div>` : ''}
          <div class="bar-track" style="height:${h}px">
            <div class="bar-fill" style="height:${pct}%;background:${d.color || 'var(--accent)'}"></div>
          </div>
          <div class="bar-label">${d.label}</div>
          <div class="bar-value">${opts.currency ? currency(d.value) : d.value}</div>
        </div>`;
    }).join('');
    return `<div class="bar-chart">${bars}</div>`;
  };

  return { currency, date, datetime, pct, margin, toast, modal, closeModal, confirm, val, numVal, setVal, formData, table, stockBadge, statusBadge, CATEGORIES, categoryOpts, printReceipt, barChart };
})();

// Close modal on backdrop click
document.addEventListener('click', (e) => {
  if (e.target.id === 'app-modal') Utils.closeModal('cancel');
});
