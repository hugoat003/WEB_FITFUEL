@echo off
setlocal
title GymStockPro - quitar arranque automatico

REM Deshace lo que hizo instalar-servicios.bat. El tunel y sus credenciales
REM en Cloudflare NO se tocan: la direccion app.fitfuelgt.com sigue siendo
REM tuya, solo deja de publicarse desde esta maquina.
REM Ejecutar como administrador.

net session >nul 2>&1
if errorlevel 1 (
  echo   Necesita administrador: clic derecho ^> "Ejecutar como administrador".
  pause
  exit /b 1
)

echo Quitando el servicio cloudflared...
sc stop cloudflared >nul 2>&1
"%~dp0bin\cloudflared.exe" service uninstall >nul 2>&1
sc delete cloudflared >nul 2>&1

echo Quitando la tarea del servidor...
schtasks /delete /tn "GymStockServidor" /f >nul 2>&1

for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":3000" ^| findstr LISTENING') do taskkill /f /pid %%p >nul 2>&1

echo.
echo Hecho. Ya nada arranca solo; usa INICIAR.bat cuando quieras la app.
echo.
pause
