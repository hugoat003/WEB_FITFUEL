' Arranca SOLO el servidor local (sin tunel) y sin ventana visible.
' Para usar la app tambien desde el celular, usa INICIAR.bat en su lugar.

Dim scriptDir, py, fso
scriptDir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))

Set fso = CreateObject("Scripting.FileSystemObject")
py = "C:\Users\Admin\AppData\Local\Programs\Python\Python312\python.exe"
If Not fso.FileExists(py) Then py = "python"

Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """" & py & """ """ & scriptDir & "server.py""", 0, False
