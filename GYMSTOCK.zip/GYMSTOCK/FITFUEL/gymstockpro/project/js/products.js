// GymStockPro — Products Module
window.ProductsModule = (() => {

  const render = async () => {
    const products = await GymDB.getAll('products');
    const search = document.getElementById('prod-search')?.value?.toLowerCase() || '';
    const catFilter = document.getElementById('prod-cat-filter')?.value || '';

    const filtered = products.filter(p => {
      const matchSearch = !search || p.name?.toLowerCase().includes(search) || p.sku?.toLowerCase().includes(search) || p.brand?.toLowerCase().includes(search);
      const matchCat = !catFilter || p.category === catFilter;
      return matchSearch && matchCat;
    });

    const rows = filtered.map(p => {
      const margin = Utils.margin(p.buyPrice, p.salePrice);
      return [
        `<span class="product-name">${p.name}</span>`,
        `<span class="cat-tag">${p.category || '—'}</span>`,
        p.brand || '—',
        `<code>${p.sku || '—'}</code>`,
        `<b>${p.stock ?? 0}</b>`,
        Utils.stockBadge(p.stock ?? 0, p.minStock ?? 5),
        Utils.currency(p.salePrice),
        `<span class="margin-pct ${margin < 20 ? 'low-margin' : ''}">${Utils.pct(margin)}</span>`,
        `<div class="action-btns">
          <button class="btn btn-sm btn-ghost" onclick="ProductsModule.openMovement(${p.id})">📦 Movimiento</button>
          <button class="btn btn-sm btn-ghost" onclick="ProductsModule.edit(${p.id})">✏️</button>
          <button class="btn btn-sm btn-danger-ghost" onclick="ProductsModule.delete(${p.id})">🗑</button>
        </div>`
      ];
    });

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Productos</h1>
          <p class="page-sub">${products.length} productos registrados</p>
        </div>
        <button class="btn btn-primary" onclick="ProductsModule.add()">+ Nuevo Producto</button>
      </div>

      <div class="toolbar">
        <input id="prod-search" class="search-input" placeholder="🔍 Buscar por nombre, SKU, marca…" oninput="ProductsModule.render()" value="${search}">
        <select id="prod-cat-filter" class="select-input" onchange="ProductsModule.render()">
          <option value="">Todas las categorías</option>
          ${Utils.CATEGORIES.map(c => `<option value="${c}" ${c===catFilter?'selected':''}>${c}</option>`).join('')}
        </select>
      </div>

      ${Utils.table(
        ['Nombre','Categoría','Marca','SKU','Stock','Estado','Precio Venta','Margen','Acciones'],
        rows,
        { emptyMsg: 'No hay productos. ¡Agrega tu primer producto!' }
      )}
    `;
  };

  const formHTML = (p = {}) => `
    <div class="form-grid">
      <div class="form-group form-col-2">
        <label>Nombre *</label>
        <input id="f-name" class="form-input" value="${p.name||''}" placeholder="Ej: Whey Protein Gold Standard" required>
      </div>
      <div class="form-group">
        <label>Categoría *</label>
        <select id="f-category" class="form-input">
          ${Utils.categoryOpts(p.category)}
        </select>
      </div>
      <div class="form-group">
        <label>Marca</label>
        <input id="f-brand" class="form-input" value="${p.brand||''}" placeholder="Ej: Optimum Nutrition">
      </div>
      <div class="form-group">
        <label>SKU / ID</label>
        <input id="f-sku" class="form-input" value="${p.sku||''}" placeholder="Ej: ON-WP-2LB">
      </div>
      <div class="form-group form-col-2">
        <label>Descripción</label>
        <textarea id="f-desc" class="form-input" rows="2" placeholder="Sabor, presentación, etc.">${p.description||''}</textarea>
      </div>
      <div class="form-group">
        <label>Precio de Compra *</label>
        <input id="f-buy" type="number" step="0.01" class="form-input" value="${p.buyPrice||''}" placeholder="0.00">
      </div>
      <div class="form-group">
        <label>Precio Venta Público *</label>
        <input id="f-sale" type="number" step="0.01" class="form-input" value="${p.salePrice||''}" placeholder="0.00" oninput="ProductsModule.updateMarginPreview()">
      </div>
      <div class="form-group">
        <label>Precio Mayoreo</label>
        <input id="f-wholesale" type="number" step="0.01" class="form-input" value="${p.wholesalePrice||''}" placeholder="0.00">
      </div>
      <div class="form-group">
        <label>Margen estimado</label>
        <div id="margin-preview" class="margin-display">—</div>
      </div>
      ${!p.id ? `
      <div class="form-group">
        <label>Stock inicial</label>
        <input id="f-stock" type="number" class="form-input" value="${p.stock||0}" min="0">
      </div>` : ''}
      <div class="form-group">
        <label>Stock mínimo</label>
        <input id="f-minstock" type="number" class="form-input" value="${p.minStock||5}" min="0">
      </div>
    </div>`;

  const add = async () => {
    const result = await Utils.modal('Nuevo Producto', formHTML(), { wide: true });
    if (result !== 'confirm') return;
    const buy = Utils.numVal('f-buy'), sale = Utils.numVal('f-sale');
    if (!Utils.val('f-name') || !sale) { Utils.toast('Nombre y precio de venta son requeridos', 'error'); return; }
    const now = new Date().toISOString();
    const id = await GymDB.add('products', {
      name: Utils.val('f-name'), category: Utils.val('f-category'),
      brand: Utils.val('f-brand'), sku: Utils.val('f-sku'),
      description: Utils.val('f-desc'), buyPrice: buy,
      salePrice: sale, wholesalePrice: Utils.numVal('f-wholesale'),
      stock: Utils.numVal('f-stock'), minStock: Utils.numVal('f-minstock'),
      createdAt: now, updatedAt: now
    });
    const initStock = Utils.numVal('f-stock');
    if (initStock > 0) {
      await GymDB.add('movements', {
        productId: id, productName: Utils.val('f-name'),
        type: 'entry', quantity: initStock, stockAfter: initStock,
        notes: 'Stock inicial', date: now
      });
    }
    Utils.toast('Producto agregado');
    render();
  };

  const edit = async (id) => {
    const p = await GymDB.getById('products', id);
    const result = await Utils.modal('Editar Producto', formHTML(p), { wide: true });
    if (result !== 'confirm') return;
    const buy = Utils.numVal('f-buy'), sale = Utils.numVal('f-sale');
    if (!Utils.val('f-name') || !sale) { Utils.toast('Nombre y precio son requeridos', 'error'); return; }
    await GymDB.put('products', {
      ...p,
      name: Utils.val('f-name'), category: Utils.val('f-category'),
      brand: Utils.val('f-brand'), sku: Utils.val('f-sku'),
      description: Utils.val('f-desc'), buyPrice: buy,
      salePrice: sale, wholesalePrice: Utils.numVal('f-wholesale'),
      minStock: Utils.numVal('f-minstock'), updatedAt: new Date().toISOString()
    });
    Utils.toast('Producto actualizado');
    render();
  };

  const deleteProduct = async (id) => {
    const ok = await Utils.confirm('¿Eliminar este producto? Esta acción no se puede deshacer.');
    if (!ok) return;
    await GymDB.remove('products', id);
    Utils.toast('Producto eliminado', 'info');
    render();
  };

  const openMovement = async (id) => {
    const p = await GymDB.getById('products', id);
    const body = `
      <p style="margin-bottom:12px">Producto: <b>${p.name}</b> — Stock actual: <b>${p.stock}</b></p>
      <div class="form-grid">
        <div class="form-group">
          <label>Tipo de movimiento</label>
          <select id="mv-type" class="form-input">
            <option value="entry">📥 Entrada</option>
            <option value="adjustment">🔧 Ajuste</option>
          </select>
        </div>
        <div class="form-group">
          <label>Cantidad</label>
          <input id="mv-qty" type="number" class="form-input" value="1" min="1">
        </div>
        <div class="form-group form-col-2">
          <label>Notas</label>
          <input id="mv-notes" class="form-input" placeholder="Motivo del movimiento">
        </div>
      </div>`;
    const result = await Utils.modal(`Movimiento — ${p.name}`, body);
    if (result !== 'confirm') return;
    const type = Utils.val('mv-type');
    const qty = Utils.numVal('mv-qty');
    if (!qty) { Utils.toast('Ingresa una cantidad válida', 'error'); return; }
    const delta = type === 'adjustment' ? qty : qty;
    await GymDB.updateStock(id, delta, type, Utils.val('mv-notes'));
    Utils.toast('Movimiento registrado');
    render();
  };

  // Called from form inline
  window.ProductsModule = window.ProductsModule || {};
  window.ProductsModule.updateMarginPreview = () => {
    const buy = parseFloat(document.getElementById('f-buy')?.value) || 0;
    const sale = parseFloat(document.getElementById('f-sale')?.value) || 0;
    const el = document.getElementById('margin-preview');
    if (!el) return;
    if (!sale) { el.textContent = '—'; return; }
    const m = Utils.margin(buy, sale);
    el.textContent = Utils.pct(m);
    el.className = `margin-display ${m < 20 ? 'low' : m > 40 ? 'high' : 'mid'}`;
  };

  return { render, add, edit, delete: deleteProduct, openMovement, updateMarginPreview: window.ProductsModule?.updateMarginPreview };
})();
