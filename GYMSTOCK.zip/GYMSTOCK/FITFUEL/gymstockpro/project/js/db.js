// GymStockPro — IndexedDB Layer
const DB_NAME = 'GymStockPro';
const DB_VERSION = 1;

window.GymDB = (() => {
  let db = null;

  const init = () => new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => { db = request.result; resolve(db); };
    request.onupgradeneeded = (e) => {
      const d = e.target.result;

      if (!d.objectStoreNames.contains('products')) {
        const ps = d.createObjectStore('products', { keyPath: 'id', autoIncrement: true });
        ps.createIndex('sku', 'sku', { unique: true });
        ps.createIndex('category', 'category');
        ps.createIndex('brand', 'brand');
      }
      if (!d.objectStoreNames.contains('movements')) {
        const ms = d.createObjectStore('movements', { keyPath: 'id', autoIncrement: true });
        ms.createIndex('productId', 'productId');
        ms.createIndex('type', 'type');
        ms.createIndex('date', 'date');
      }
      if (!d.objectStoreNames.contains('sales')) {
        const ss = d.createObjectStore('sales', { keyPath: 'id', autoIncrement: true });
        ss.createIndex('date', 'date');
        ss.createIndex('clientId', 'clientId');
      }
      if (!d.objectStoreNames.contains('consignments')) {
        const cs = d.createObjectStore('consignments', { keyPath: 'id', autoIncrement: true });
        cs.createIndex('clientId', 'clientId');
        cs.createIndex('status', 'status');
      }
      if (!d.objectStoreNames.contains('clients')) {
        d.createObjectStore('clients', { keyPath: 'id', autoIncrement: true });
      }
      if (!d.objectStoreNames.contains('suppliers')) {
        d.createObjectStore('suppliers', { keyPath: 'id', autoIncrement: true });
      }
      if (!d.objectStoreNames.contains('purchases')) {
        const pu = d.createObjectStore('purchases', { keyPath: 'id', autoIncrement: true });
        pu.createIndex('supplierId', 'supplierId');
        pu.createIndex('date', 'date');
      }
      if (!d.objectStoreNames.contains('settings')) {
        d.createObjectStore('settings', { keyPath: 'key' });
      }
    };
  });

  const tx = (store, mode = 'readonly') => db.transaction(store, mode).objectStore(store);

  const getAll = (store) => new Promise((res, rej) => {
    const r = tx(store).getAll();
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const getById = (store, id) => new Promise((res, rej) => {
    const r = tx(store).get(id);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const add = (store, data) => new Promise((res, rej) => {
    const r = tx(store, 'readwrite').add(data);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const put = (store, data) => new Promise((res, rej) => {
    const r = tx(store, 'readwrite').put(data);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const remove = (store, id) => new Promise((res, rej) => {
    const r = tx(store, 'readwrite').delete(id);
    r.onsuccess = () => res();
    r.onerror = () => rej(r.error);
  });

  const getByIndex = (store, indexName, value) => new Promise((res, rej) => {
    const r = tx(store).index(indexName).getAll(value);
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const getSetting = (key) => new Promise((res, rej) => {
    const r = tx('settings').get(key);
    r.onsuccess = () => res(r.result ? r.result.value : null);
    r.onerror = () => rej(r.error);
  });

  const setSetting = (key, value) => put('settings', { key, value });

  // Update product stock
  const updateStock = async (productId, delta, movementType, notes = '') => {
    const product = await getById('products', productId);
    if (!product) throw new Error('Producto no encontrado');
    product.stock = (product.stock || 0) + delta;
    product.updatedAt = new Date().toISOString();
    await put('products', product);
    await add('movements', {
      productId,
      productName: product.name,
      type: movementType,
      quantity: delta,
      stockAfter: product.stock,
      notes,
      date: new Date().toISOString()
    });
    return product;
  };

  return { init, getAll, getById, add, put, remove, getByIndex, getSetting, setSetting, updateStock };
})();
