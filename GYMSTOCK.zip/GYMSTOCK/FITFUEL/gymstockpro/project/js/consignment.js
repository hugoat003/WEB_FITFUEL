// GymStockPro — Consignment Module
window.ConsignmentModule = (() => {

  const render = async () => {
    const consignments = await GymDB.getAll('consignments');
    const clients = await GymDB.getAll('clients');
    consignments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const clientMap = Object.fromEntries(clients.map(c => [c.id, c.name]));

    const rows = consignments.map(c => {
      const pending = c.items?.filter(i => i.status === 'pendiente').length || 0;
      const sold = c.items?.filter(i => i.status === 'vendido').length || 0;
      const returned = c.items?.filter(i => i.status === 'devuelto').length || 0;
      return [
        `<b>#${c.id}</b>`,
        clientMap[c.clientId] || '—',
        Utils.date(c.createdAt),
        c.items?.length || 0,
        pending ? `<span class="badge badge-warning">${pending} pendiente(s)</span>` : '—',
        sold ? `<span class="badge badge-ok">${sold} vendido(s)</span>` : '—',
        returned ? `<span class="badge badge-info">${returned} devuelto(s)</span>` : '—',
        `<div class="action-btns">
          <button class="btn btn-sm btn-primary" onclick="ConsignmentModule.manage(${c.id})">Gestionar</button>
          <button class="btn btn-sm btn-danger-ghost" onclick="ConsignmentModule.delete(${c.id})">🗑</button>
        </div>`
      ];
    });

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Consignaciones</h1>
          <p class="page-sub">${consignments.length} consignaciones — ${consignments.filter(c=>c.items?.some(i=>i.status==='pendiente')).length} con items pendientes</p>
        </div>
        <div class="header-actions">
          <button class="btn btn-ghost" onclick="ConsignmentModule.renderClients()">👥 Clientes</button>
          <button class="btn btn-primary" onclick="ConsignmentModule.newConsignment()">+ Nueva Consignación</button>
        </div>
      </div>
      ${Utils.table(['#','Cliente','Fecha','Items','Pendientes','Vendidos','Devueltos','Acciones'], rows, { emptyMsg: 'No hay consignaciones registradas' })}
    `;
  };

  const renderClients = async () => {
    const clients = await GymDB.getAll('clients');
    const rows = clients.map(c => [
      `<b>${c.name}</b>`,
      c.phone || '—',
      c.email || '—',
      c.address || '—',
      `<div class="action-btns">
        <button class="btn btn-sm btn-ghost" onclick="ConsignmentModule.editClient(${c.id})">✏️</button>
        <button class="btn btn-sm btn-danger-ghost" onclick="ConsignmentModule.deleteClient(${c.id})">🗑</button>
      </div>`
    ]);

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Clientes</h1>
          <p class="page-sub">${clients.length} clientes registrados</p>
        </div>
        <div class="header-actions">
          <button class="btn btn-ghost" onclick="ConsignmentModule.render()">← Consignaciones</button>
          <button class="btn btn-primary" onclick="ConsignmentModule.addClient()">+ Nuevo Cliente</button>
        </div>
      </div>
      ${Utils.table(['Nombre','Teléfono','Email','Dirección','Acciones'], rows, { emptyMsg: 'No hay clientes registrados' })}
    `;
  };

  const clientFormHTML = (c = {}) => `
    <div class="form-grid">
      <div class="form-group form-col-2">
        <label>Nombre *</label>
        <input id="c-name" class="form-input" value="${c.name||''}" placeholder="Nombre completo">
      </div>
      <div class="form-group">
        <label>Teléfono</label>
        <input id="c-phone" class="form-input" value="${c.phone||''}" placeholder="+52 000 000 0000">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input id="c-email" class="form-input" type="email" value="${c.email||''}" placeholder="correo@ejemplo.com">
      </div>
      <div class="form-group form-col-2">
        <label>Dirección</label>
        <input id="c-address" class="form-input" value="${c.address||''}" placeholder="Dirección">
      </div>
      <div class="form-group form-col-2">
        <label>Notas</label>
        <textarea id="c-notes" class="form-input" rows="2">${c.notes||''}</textarea>
      </div>
    </div>`;

  const addClient = async () => {
    const r = await Utils.modal('Nuevo Cliente', clientFormHTML());
    if (r !== 'confirm') return;
    if (!Utils.val('c-name')) { Utils.toast('El nombre es requerido', 'error'); return; }
    await GymDB.add('clients', {
      name: Utils.val('c-name'), phone: Utils.val('c-phone'),
      email: Utils.val('c-email'), address: Utils.val('c-address'),
      notes: Utils.val('c-notes'), createdAt: new Date().toISOString()
    });
    Utils.toast('Cliente agregado');
    renderClients();
  };

  const editClient = async (id) => {
    const c = await GymDB.getById('clients', id);
    const r = await Utils.modal('Editar Cliente', clientFormHTML(c));
    if (r !== 'confirm') return;
    await GymDB.put('clients', { ...c, name: Utils.val('c-name'), phone: Utils.val('c-phone'), email: Utils.val('c-email'), address: Utils.val('c-address'), notes: Utils.val('c-notes') });
    Utils.toast('Cliente actualizado');
    renderClients();
  };

  const deleteClient = async (id) => {
    const ok = await Utils.confirm('¿Eliminar este cliente?');
    if (!ok) return;
    await GymDB.remove('clients', id);
    Utils.toast('Cliente eliminado', 'info');
    renderClients();
  };

  const newConsignment = async () => {
    const clients = await GymDB.getAll('clients');
    const products = await GymDB.getAll('products');
    if (!clients.length) { Utils.toast('Primero agrega un cliente', 'error'); return; }

    const clientOpts = clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    const productOpts = products.filter(p => (p.stock||0) > 0)
      .map(p => `<option value="${p.id}" data-price="${p.salePrice}" data-stock="${p.stock}">${p.name} (Stock: ${p.stock})</option>`).join('');

    const body = `
      <div class="form-grid">
        <div class="form-group form-col-2">
          <label>Cliente *</label>
          <select id="cs-client" class="form-input">${clientOpts}</select>
        </div>
      </div>
      <div class="cart-add-row">
        <select id="cs-product" class="form-input" style="flex:2">${productOpts}</select>
        <input id="cs-qty" type="number" class="form-input" value="1" min="1" style="width:80px">
        <button class="btn btn-accent" onclick="ConsignmentModule._addItem()">+ Agregar</button>
      </div>
      <div id="cs-items-table"><div class="empty-state" style="padding:20px"><span>📋</span><p>Sin productos</p></div></div>`;

    window._csItems = [];
    const r = await Utils.modal('Nueva Consignación', body, { wide: true, confirmLabel: 'Crear Consignación' });
    if (r !== 'confirm') return;
    if (!window._csItems.length) { Utils.toast('Agrega al menos un producto', 'error'); return; }

    const clientId = parseInt(Utils.val('cs-client'));
    const now = new Date().toISOString();
    const id = await GymDB.add('consignments', {
      clientId, items: window._csItems.map(i => ({ ...i, status: 'pendiente' })),
      createdAt: now, updatedAt: now
    });

    for (const item of window._csItems) {
      await GymDB.updateStock(item.productId, -item.quantity, 'consignment', `Consignación #${id}`);
    }

    Utils.toast('Consignación registrada');
    render();
  };

  window.ConsignmentModule = window.ConsignmentModule || {};
  window.ConsignmentModule._addItem = () => {
    const sel = document.getElementById('cs-product');
    const pid = parseInt(sel.value);
    const qty = parseInt(document.getElementById('cs-qty').value) || 1;
    const opt = sel.options[sel.selectedIndex];
    const stock = parseInt(opt.dataset.stock);
    if (qty > stock) { Utils.toast(`Solo hay ${stock} en stock`, 'error'); return; }
    const price = parseFloat(opt.dataset.price);
    const existing = window._csItems.find(i => i.productId === pid);
    if (existing) existing.quantity += qty;
    else window._csItems.push({ productId: pid, productName: opt.text.split(' (Stock')[0], quantity: qty, salePrice: price });
    refreshCSTable();
  };

  const refreshCSTable = () => {
    const rows = window._csItems.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.salePrice)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="window._csItems.splice(${i},1);ConsignmentModule._refreshCSTable()">✕</button></td>
      </tr>`).join('');
    document.getElementById('cs-items-table').innerHTML = window._csItems.length ? `
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Precio Venta</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>` : `<div class="empty-state" style="padding:20px"><span>📋</span><p>Sin productos</p></div>`;
  };
  window.ConsignmentModule._refreshCSTable = refreshCSTable;

  const manage = async (id) => {
    const cs = await GymDB.getById('consignments', id);
    const client = await GymDB.getById('clients', cs.clientId);

    const rows = cs.items.map((item, idx) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.status === 'pendiente'
          ? `<input id="cs-sell-qty-${idx}" type="number" class="form-input" value="${item.quantity}" min="1" max="${item.quantity}" style="width:70px;padding:5px 8px">`
          : item.quantity}</td>
        <td>${Utils.currency(item.salePrice)}</td>
        <td>${Utils.statusBadge(item.status)}</td>
        <td>
          ${item.status === 'pendiente' ? `
            <div class="action-btns">
              <button class="btn btn-sm btn-primary" onclick="ConsignmentModule._markSold(${id}, ${idx})">✓ Vendido</button>
              <button class="btn btn-sm btn-ghost" onclick="ConsignmentModule._markReturned(${id}, ${idx})">↩ Devolver</button>
            </div>` : `<span style="color:var(--text-muted);font-size:13px">—</span>`}
        </td>
      </tr>`).join('');

    const body = `
      <div class="info-row" style="margin-bottom:16px">
        <span>Cliente: <b>${client?.name || '—'}</b></span>
        <span>Fecha: <b>${Utils.date(cs.createdAt)}</b></span>
      </div>
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;

    window._currentCS = cs;
    await Utils.modal(`Consignación #${id} — ${client?.name}`, body, {
      wide: true,
      buttons: [{ label: 'Cerrar', cls: 'btn-ghost', value: 'cancel' }]
    });
    render();
  };

  window.ConsignmentModule._markSold = async (csId, idx) => {
    const cs = await GymDB.getById('consignments', csId);
    const item = cs.items[idx];

    // Read quantity from inline input in the manage modal
    const inlineInput = document.getElementById(`cs-sell-qty-${idx}`);
    const soldQty = Math.min(Math.max(parseInt(inlineInput?.value) || item.quantity, 1), item.quantity);
    const remaining = item.quantity - soldQty;
    const now = new Date().toISOString();

    if (remaining > 0) {
      // Partial: split item — mark sold qty, keep remaining as pending
      cs.items[idx] = { ...item, quantity: soldQty, status: 'vendido' };
      cs.items.push({ ...item, quantity: remaining, status: 'pendiente' });
    } else {
      cs.items[idx].status = 'vendido';
    }
    cs.updatedAt = now;
    await GymDB.put('consignments', cs);

    // Convert to real sale
    const saleId = await GymDB.add('sales', {
      type: 'retail', clientId: cs.clientId,
      items: [{ productId: item.productId, productName: item.productName, quantity: soldQty, price: item.salePrice }],
      total: soldQty * item.salePrice, date: now,
      fromConsignment: csId
    });
    await GymDB.add('movements', {
      productId: item.productId, productName: item.productName,
      type: 'sale', quantity: -soldQty, notes: `Venta desde consignación #${csId} → Venta #${saleId}`, date: now
    });

    Utils.toast(`${soldQty} unidad(es) vendida(s)${remaining > 0 ? ` — ${remaining} siguen pendientes` : ''}`);
    manage(csId);
  };

  window.ConsignmentModule._markReturned = async (csId, idx) => {
    const cs = await GymDB.getById('consignments', csId);
    const item = cs.items[idx];
    item.status = 'devuelto';
    cs.updatedAt = new Date().toISOString();
    await GymDB.put('consignments', cs);
    await GymDB.updateStock(item.productId, item.quantity, 'return', `Devolución de consignación #${csId}`);
    Utils.toast('Producto devuelto al inventario');
    manage(csId);
  };

  const deleteConsignment = async (id) => {
    const ok = await Utils.confirm('¿Eliminar consignación? Los items pendientes NO se regresarán al inventario automáticamente.');
    if (!ok) return;
    await GymDB.remove('consignments', id);
    Utils.toast('Consignación eliminada', 'info');
    render();
  };

  return { render, renderClients, addClient, editClient, deleteClient: deleteClient, newConsignment, manage, delete: deleteConsignment, _addItem: window.ConsignmentModule._addItem, _markSold: window.ConsignmentModule._markSold, _markReturned: window.ConsignmentModule._markReturned, _refreshCSTable: refreshCSTable };
})();
