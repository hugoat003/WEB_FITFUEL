// GymStockPro — Suppliers Module
window.SuppliersModule = (() => {

  const render = async () => {
    const suppliers = await GymDB.getAll('suppliers');
    const purchases = await GymDB.getAll('purchases');

    const rows = suppliers.map(s => {
      const pCount = purchases.filter(p => p.supplierId === s.id).length;
      return [
        `<b>${s.name}</b>`,
        s.contact || '—',
        s.phone || '—',
        s.email || '—',
        pCount,
        `<div class="action-btns">
          <button class="btn btn-sm btn-primary" onclick="SuppliersModule.newPurchase(${s.id})">📥 Compra</button>
          <button class="btn btn-sm btn-ghost" onclick="SuppliersModule.edit(${s.id})">✏️</button>
          <button class="btn btn-sm btn-danger-ghost" onclick="SuppliersModule.delete(${s.id})">🗑</button>
        </div>`
      ];
    });

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Proveedores</h1>
          <p class="page-sub">${suppliers.length} proveedores registrados</p>
        </div>
        <div class="header-actions">
          <button class="btn btn-ghost" onclick="SuppliersModule.renderPurchases()">📋 Historial de Compras</button>
          <button class="btn btn-primary" onclick="SuppliersModule.add()">+ Nuevo Proveedor</button>
        </div>
      </div>
      ${Utils.table(['Nombre','Contacto','Teléfono','Email','Compras','Acciones'], rows, { emptyMsg: 'No hay proveedores registrados' })}
    `;
  };

  const renderPurchases = async () => {
    const purchases = await GymDB.getAll('purchases');
    const suppliers = await GymDB.getAll('suppliers');
    const supplierMap = Object.fromEntries(suppliers.map(s => [s.id, s.name]));
    purchases.sort((a, b) => new Date(b.date) - new Date(a.date));

    const rows = purchases.map(p => [
      `<b>#${p.id}</b>`,
      supplierMap[p.supplierId] || '—',
      Utils.date(p.date),
      p.items?.length || 0,
      Utils.currency(p.total),
      p.notes || '—'
    ]);

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Historial de Compras</h1>
          <p class="page-sub">${purchases.length} compras registradas</p>
        </div>
        <button class="btn btn-ghost" onclick="SuppliersModule.render()">← Proveedores</button>
      </div>
      ${Utils.table(['#','Proveedor','Fecha','Productos','Total','Notas'], rows, { emptyMsg: 'No hay compras registradas' })}
    `;
  };

  const formHTML = (s = {}) => `
    <div class="form-grid">
      <div class="form-group form-col-2">
        <label>Nombre *</label>
        <input id="s-name" class="form-input" value="${s.name||''}" placeholder="Nombre del proveedor o empresa">
      </div>
      <div class="form-group">
        <label>Persona de contacto</label>
        <input id="s-contact" class="form-input" value="${s.contact||''}" placeholder="Nombre del contacto">
      </div>
      <div class="form-group">
        <label>Teléfono</label>
        <input id="s-phone" class="form-input" value="${s.phone||''}" placeholder="+52 000 000 0000">
      </div>
      <div class="form-group">
        <label>Email</label>
        <input id="s-email" class="form-input" type="email" value="${s.email||''}" placeholder="contacto@proveedor.com">
      </div>
      <div class="form-group">
        <label>Dirección</label>
        <input id="s-address" class="form-input" value="${s.address||''}" placeholder="Dirección">
      </div>
      <div class="form-group form-col-2">
        <label>Notas</label>
        <textarea id="s-notes" class="form-input" rows="2">${s.notes||''}</textarea>
      </div>
    </div>`;

  const add = async () => {
    const r = await Utils.modal('Nuevo Proveedor', formHTML());
    if (r !== 'confirm') return;
    if (!Utils.val('s-name')) { Utils.toast('El nombre es requerido', 'error'); return; }
    await GymDB.add('suppliers', {
      name: Utils.val('s-name'), contact: Utils.val('s-contact'),
      phone: Utils.val('s-phone'), email: Utils.val('s-email'),
      address: Utils.val('s-address'), notes: Utils.val('s-notes'),
      createdAt: new Date().toISOString()
    });
    Utils.toast('Proveedor agregado');
    render();
  };

  const edit = async (id) => {
    const s = await GymDB.getById('suppliers', id);
    const r = await Utils.modal('Editar Proveedor', formHTML(s));
    if (r !== 'confirm') return;
    if (!Utils.val('s-name')) { Utils.toast('El nombre es requerido', 'error'); return; }
    await GymDB.put('suppliers', {
      ...s, name: Utils.val('s-name'), contact: Utils.val('s-contact'),
      phone: Utils.val('s-phone'), email: Utils.val('s-email'),
      address: Utils.val('s-address'), notes: Utils.val('s-notes')
    });
    Utils.toast('Proveedor actualizado');
    render();
  };

  const deleteSupplier = async (id) => {
    const ok = await Utils.confirm('¿Eliminar este proveedor?');
    if (!ok) return;
    await GymDB.remove('suppliers', id);
    Utils.toast('Proveedor eliminado', 'info');
    render();
  };

  const newPurchase = async (supplierId) => {
    const supplier = await GymDB.getById('suppliers', supplierId);
    const products = await GymDB.getAll('products');
    const productOpts = products.map(p =>
      `<option value="${p.id}" data-buy="${p.buyPrice}">${p.name} (Stock actual: ${p.stock||0})</option>`
    ).join('');

    window._purchaseItems = [];

    const body = `
      <p style="margin-bottom:12px">Proveedor: <b>${supplier.name}</b></p>
      <div class="cart-add-row">
        <select id="pu-product" class="form-input" style="flex:2">${productOpts}</select>
        <input id="pu-qty" type="number" class="form-input" value="1" min="1" style="width:80px" placeholder="Cant.">
        <input id="pu-price" type="number" class="form-input" step="0.01" style="width:100px" placeholder="Precio compra">
        <button class="btn btn-accent" onclick="SuppliersModule._addPurchaseItem()">+ Agregar</button>
      </div>
      <div id="pu-items-table"><div class="empty-state" style="padding:20px"><span>📦</span><p>Sin productos</p></div></div>
      <div class="form-group" style="margin-top:12px">
        <label>Notas de la compra</label>
        <input id="pu-notes" class="form-input" placeholder="Número de factura, observaciones…">
      </div>`;

    const r = await Utils.modal(`Nueva Compra — ${supplier.name}`, body, { wide: true, confirmLabel: 'Registrar Compra' });
    if (r !== 'confirm') return;
    if (!window._purchaseItems.length) { Utils.toast('Agrega al menos un producto', 'error'); return; }

    const total = window._purchaseItems.reduce((s, i) => s + i.quantity * i.buyPrice, 0);
    const now = new Date().toISOString();
    const purchaseId = await GymDB.add('purchases', {
      supplierId, items: window._purchaseItems, total,
      date: now, notes: Utils.val('pu-notes')
    });

    for (const item of window._purchaseItems) {
      await GymDB.updateStock(item.productId, item.quantity, 'entry', `Compra #${purchaseId} — ${supplier.name}`);
      const prod = await GymDB.getById('products', item.productId);
      if (prod && item.buyPrice) {
        await GymDB.put('products', { ...prod, buyPrice: item.buyPrice, updatedAt: now });
      }
    }

    Utils.toast(`Compra registrada — ${Utils.currency(total)}`);
    render();
  };

  window.SuppliersModule = window.SuppliersModule || {};

  window.SuppliersModule._addPurchaseItem = () => {
    const sel = document.getElementById('pu-product');
    const pid = parseInt(sel.value);
    const qty = parseInt(document.getElementById('pu-qty').value) || 1;
    const buyPrice = parseFloat(document.getElementById('pu-price').value) || parseFloat(sel.options[sel.selectedIndex].dataset.buy) || 0;
    const existing = window._purchaseItems.find(i => i.productId === pid);
    if (existing) { existing.quantity += qty; existing.buyPrice = buyPrice; }
    else window._purchaseItems.push({ productId: pid, productName: sel.options[sel.selectedIndex].text.split(' (Stock')[0], quantity: qty, buyPrice });
    refreshPurchaseTable();
  };

  const refreshPurchaseTable = () => {
    const rows = window._purchaseItems.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.buyPrice)}</td>
        <td>${Utils.currency(item.quantity * item.buyPrice)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="window._purchaseItems.splice(${i},1);SuppliersModule._refreshPurchaseTable()">✕</button></td>
      </tr>`).join('');
    const total = window._purchaseItems.reduce((s, i) => s + i.quantity * i.buyPrice, 0);
    document.getElementById('pu-items-table').innerHTML = window._purchaseItems.length ? `
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>P.Compra</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="cart-total">Total: <b>${Utils.currency(total)}</b></div>
    ` : `<div class="empty-state" style="padding:20px"><span>📦</span><p>Sin productos</p></div>`;
  };
  window.SuppliersModule._refreshPurchaseTable = refreshPurchaseTable;

  return { render, renderPurchases, add, edit, delete: deleteSupplier, newPurchase, _addPurchaseItem: window.SuppliersModule._addPurchaseItem, _refreshPurchaseTable: refreshPurchaseTable };
})();
