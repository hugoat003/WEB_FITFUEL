// GymStockPro — Reports Module
window.ReportsModule = (() => {

  const render = async () => {
    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div><h1>Reportes</h1><p class="page-sub">Análisis de ventas, inventario y ganancias</p></div>
      </div>
      <div class="report-tabs">
        <button class="rtab active" onclick="ReportsModule.showTab('ventas', this)">📈 Ventas</button>
        <button class="rtab" onclick="ReportsModule.showTab('inventario', this)">📦 Inventario</button>
        <button class="rtab" onclick="ReportsModule.showTab('ganancias', this)">💰 Ganancias</button>
        <button class="rtab" onclick="ReportsModule.showTab('consignacion', this)">🤝 Consignación</button>
        <button class="rtab" onclick="ReportsModule.showTab('movimientos', this)">🔄 Movimientos</button>
      </div>
      <div id="report-body"></div>
    `;
    showTab('ventas', document.querySelector('.rtab.active'));
  };

  const showTab = async (tab, btn) => {
    document.querySelectorAll('.rtab').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    const body = document.getElementById('report-body');
    body.innerHTML = `<div class="loading-state">Cargando…</div>`;
    switch (tab) {
      case 'ventas': body.innerHTML = await buildSalesReport(); break;
      case 'inventario': body.innerHTML = await buildInventoryReport(); break;
      case 'ganancias': body.innerHTML = await buildProfitReport(); break;
      case 'consignacion': body.innerHTML = await buildConsignmentReport(); break;
      case 'movimientos': body.innerHTML = await buildMovementsReport(); break;
    }
  };

  window.ReportsModule = { render, showTab };

  // ── Sales Report ─────────────────────────────────────────────
  const buildSalesReport = async () => {
    const sales = await GymDB.getAll('sales');
    const now = new Date();

    const periodFilter = (days) => {
      const from = new Date(now); from.setDate(from.getDate() - days);
      return sales.filter(s => new Date(s.date) >= from);
    };

    const todaySales = sales.filter(s => {
      const d = new Date(s.date);
      return d.toDateString() === now.toDateString();
    });
    const weekSales = periodFilter(7);
    const monthSales = periodFilter(30);

    const totalOf = (arr) => arr.reduce((s, v) => s + (v.total || 0), 0);

    // Last 7 days chart
    const days7 = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(d.getDate() - i);
      const label = d.toLocaleDateString('es-MX', { weekday: 'short', day: 'numeric' });
      const value = sales.filter(s => new Date(s.date).toDateString() === d.toDateString())
        .reduce((s, v) => s + v.total, 0);
      days7.push({ label, value, color: 'var(--accent)' });
    }

    // Top products
    const productTotals = {};
    sales.forEach(s => s.items?.forEach(i => {
      productTotals[i.productName] = (productTotals[i.productName] || 0) + i.quantity;
    }));
    const topProducts = Object.entries(productTotals)
      .sort((a, b) => b[1] - a[1]).slice(0, 8)
      .map(([label, value]) => ({ label: label.length > 18 ? label.slice(0,16)+'…' : label, value, color: 'var(--accent-2)' }));

    return `
      <div class="stats-grid">
        ${statCard('Hoy', Utils.currency(totalOf(todaySales)), `${todaySales.length} ventas`, '📅')}
        ${statCard('7 días', Utils.currency(totalOf(weekSales)), `${weekSales.length} ventas`, '📆')}
        ${statCard('30 días', Utils.currency(totalOf(monthSales)), `${monthSales.length} ventas`, '🗓')}
        ${statCard('Total histórico', Utils.currency(totalOf(sales)), `${sales.length} ventas`, '💳')}
      </div>
      <div class="report-section">
        <h3>Ventas últimos 7 días</h3>
        ${Utils.barChart(days7, { currency: true, height: 160 })}
      </div>
      <div class="report-section">
        <h3>Productos más vendidos (cantidad)</h3>
        ${topProducts.length ? Utils.barChart(topProducts, { height: 160 }) : '<div class="empty-state"><span>📊</span><p>Sin datos</p></div>'}
      </div>`;
  };

  // ── Inventory Report ─────────────────────────────────────────
  const buildInventoryReport = async () => {
    const products = await GymDB.getAll('products');
    products.sort((a, b) => (a.stock || 0) - (b.stock || 0));

    const lowStock = products.filter(p => (p.stock || 0) <= (p.minStock || 5) && p.stock > 0);
    const outStock = products.filter(p => (p.stock || 0) <= 0);
    const totalValue = products.reduce((s, p) => s + (p.stock || 0) * (p.buyPrice || 0), 0);
    const saleValue = products.reduce((s, p) => s + (p.stock || 0) * (p.salePrice || 0), 0);

    const rows = products.map(p => [
      p.name,
      `<span class="cat-tag">${p.category||'—'}</span>`,
      p.brand || '—',
      `<b>${p.stock || 0}</b>`,
      p.minStock || 5,
      Utils.stockBadge(p.stock || 0, p.minStock || 5),
      Utils.currency(p.buyPrice),
      Utils.currency((p.stock || 0) * (p.buyPrice || 0)),
      Utils.currency((p.stock || 0) * (p.salePrice || 0))
    ]);

    // By category chart
    const byCat = {};
    products.forEach(p => { byCat[p.category||'Otro'] = (byCat[p.category||'Otro'] || 0) + (p.stock || 0); });
    const catData = Object.entries(byCat).map(([label, value]) => ({ label, value }));

    return `
      <div class="stats-grid">
        ${statCard('Productos', products.length, 'en catálogo', '📦')}
        ${statCard('Sin stock', outStock.length, 'agotados', '❌')}
        ${statCard('Bajo stock', lowStock.length, 'alertas', '⚠️')}
        ${statCard('Valor inventario', Utils.currency(totalValue), 'precio compra', '💰')}
        ${statCard('Valor venta', Utils.currency(saleValue), 'precio público', '🏷')}
      </div>
      ${lowStock.length || outStock.length ? `
      <div class="alert-box">
        <b>⚠ Alertas de stock:</b>
        ${outStock.map(p => `<span class="badge badge-danger" style="margin:2px">${p.name}: AGOTADO</span>`).join('')}
        ${lowStock.map(p => `<span class="badge badge-warning" style="margin:2px">${p.name}: ${p.stock}</span>`).join('')}
      </div>` : ''}
      <div class="report-section">
        <h3>Stock por categoría</h3>
        ${Utils.barChart(catData, { height: 150 })}
      </div>
      <div class="report-section">
        <h3>Inventario completo</h3>
        ${Utils.table(['Producto','Categoría','Marca','Stock','Mín.','Estado','P.Compra','Val.Costo','Val.Venta'], rows)}
      </div>`;
  };

  // ── Profit Report ────────────────────────────────────────────
  const buildProfitReport = async () => {
    const sales = await GymDB.getAll('sales');
    const products = await GymDB.getAll('products');
    const purchases = await GymDB.getAll('purchases');
    const productMap = Object.fromEntries(products.map(p => [p.id, p]));

    let totalRevenue = 0, totalCost = 0;
    const byProduct = {};
    const byMonth = {};

    sales.forEach(s => {
      const monthKey = new Date(s.date).toLocaleDateString('es-MX', { month:'short', year:'numeric' });
      if (!byMonth[monthKey]) byMonth[monthKey] = { revenue: 0, cost: 0 };
      s.items?.forEach(i => {
        const p = productMap[i.productId];
        const cost = (p?.buyPrice || 0) * i.quantity;
        const rev = i.price * i.quantity;
        totalRevenue += rev;
        totalCost += cost;
        byMonth[monthKey].revenue += rev;
        byMonth[monthKey].cost += cost;
        if (!byProduct[i.productId]) byProduct[i.productId] = { name: i.productName, revenue: 0, cost: 0, qty: 0 };
        byProduct[i.productId].revenue += rev;
        byProduct[i.productId].cost += cost;
        byProduct[i.productId].qty += i.quantity;
      });
    });

    const totalPurchaseCost = purchases.reduce((s, p) => s + (p.total || 0), 0);
    const totalProfit = totalRevenue - totalCost;
    const profitPct = totalRevenue ? (totalProfit / totalRevenue * 100) : 0;

    // Monthly comparison chart
    const months = Object.entries(byMonth).slice(-6);
    const maxMonthVal = Math.max(...months.map(([,v]) => Math.max(v.revenue, v.cost)), 1);
    const monthChart = months.map(([label, v]) => {
      const profit = v.revenue - v.cost;
      return `
        <div class="month-col">
          <div class="month-bars">
            <div class="mbar revenue" style="height:${(v.revenue/maxMonthVal)*120}px" title="Ventas: ${Utils.currency(v.revenue)}">
              <span class="mbar-tip">${Utils.currency(v.revenue)}</span>
            </div>
            <div class="mbar cost" style="height:${(v.cost/maxMonthVal)*120}px" title="Costo: ${Utils.currency(v.cost)}">
              <span class="mbar-tip">${Utils.currency(v.cost)}</span>
            </div>
            <div class="mbar profit" style="height:${Math.max((Math.abs(profit)/maxMonthVal)*120,2)}px;background:${profit>=0?'var(--green)':'var(--red)'}" title="Ganancia: ${Utils.currency(profit)}">
              <span class="mbar-tip">${Utils.currency(profit)}</span>
            </div>
          </div>
          <div class="month-label">${label}</div>
        </div>`;
    }).join('');

    // Top products by profit
    const topByProfit = Object.values(byProduct).sort((a,b) => (b.revenue-b.cost)-(a.revenue-a.cost)).slice(0,6);
    const maxProfit = Math.max(...topByProfit.map(p => p.revenue - p.cost), 1);
    const productProfitBars = topByProfit.map(p => {
      const profit = p.revenue - p.cost;
      const pct = (profit / maxProfit) * 100;
      const margin = p.revenue ? (profit / p.revenue * 100) : 0;
      return `
        <div class="hbar-row">
          <div class="hbar-name">${p.name.length > 22 ? p.name.slice(0,20)+'…' : p.name}</div>
          <div class="hbar-track">
            <div class="hbar-fill" style="width:${Math.max(pct,2)}%;background:${profit>=0?'var(--green)':'var(--red)'}"></div>
          </div>
          <div class="hbar-vals">
            <span class="hbar-profit" style="color:${profit>=0?'var(--green)':'var(--red)'}">${Utils.currency(profit)}</span>
            <span class="hbar-margin">${Utils.pct(margin)}</span>
          </div>
        </div>`;
    }).join('');

    const rows = Object.values(byProduct)
      .sort((a, b) => (b.revenue - b.cost) - (a.revenue - a.cost))
      .map(p => {
        const profit = p.revenue - p.cost;
        const pct = p.revenue ? (profit / p.revenue * 100) : 0;
        return [
          p.name, p.qty,
          Utils.currency(p.revenue),
          Utils.currency(p.cost),
          `<b style="color:${profit>=0?'var(--green)':'var(--red)'}">${Utils.currency(profit)}</b>`,
          `<span class="${pct < 20 ? 'low-margin' : ''}">${Utils.pct(pct)}</span>`
        ];
      });

    return `
      <div class="stats-grid">
        ${statCard('Ingresos', Utils.currency(totalRevenue), 'ventas brutas', '📈')}
        ${statCard('Costo de ventas', Utils.currency(totalCost), 'basado en precio compra', '📉')}
        ${statCard('Ganancia neta', Utils.currency(totalProfit), `${Utils.pct(profitPct)} margen`, '💵')}
        ${statCard('Invertido en compras', Utils.currency(totalPurchaseCost), `${purchases.length} órdenes de compra`, '🛒')}
      </div>

      <!-- P&L Visual -->
      <div class="pnl-visual-strip">
        <div class="pnl-bar-wrap">
          <div class="pnl-label-top">Ingresos</div>
          <div class="pnl-big-bar income-bar" style="width:100%">${Utils.currency(totalRevenue)}</div>
        </div>
        <div class="pnl-bar-wrap">
          <div class="pnl-label-top">Costo de ventas</div>
          <div class="pnl-big-bar cost-bar" style="width:${totalRevenue?(totalCost/totalRevenue*100):0}%">${Utils.currency(totalCost)}</div>
        </div>
        <div class="pnl-bar-wrap">
          <div class="pnl-label-top">Ganancia neta</div>
          <div class="pnl-big-bar profit-bar" style="width:${totalRevenue?(totalProfit/totalRevenue*100):0}%;background:${totalProfit>=0?'var(--green)':'var(--red)'}">${Utils.currency(totalProfit)}</div>
        </div>
        <div class="pnl-bar-wrap">
          <div class="pnl-label-top">Total invertido en stock (compras)</div>
          <div class="pnl-big-bar purchases-bar" style="width:${totalRevenue?(totalPurchaseCost/totalRevenue*100):0}%">${Utils.currency(totalPurchaseCost)}</div>
        </div>
      </div>

      ${months.length ? `
      <div class="report-section">
        <h3>Ventas vs Costos por mes
          <span class="chart-legend" style="margin-left:auto">
            <span class="leg rev">Ventas</span>
            <span class="leg cost">Costo</span>
            <span class="leg profit-leg">Ganancia</span>
          </span>
        </h3>
        <div class="month-chart">${monthChart}</div>
      </div>` : ''}

      ${topByProfit.length ? `
      <div class="report-section">
        <h3>Top productos por ganancia</h3>
        <div class="hbar-chart">${productProfitBars}</div>
      </div>` : ''}

      <div class="report-section">
        <h3>Detalle por producto</h3>
        ${Utils.table(['Producto','Cant. Vendida','Ingresos','Costo','Ganancia','Margen'], rows, { emptyMsg: 'Sin ventas registradas' })}
      </div>`;
  };

  // ── Consignment Report ───────────────────────────────────────
  const buildConsignmentReport = async () => {
    const consignments = await GymDB.getAll('consignments');
    const clients = await GymDB.getAll('clients');
    const clientMap = Object.fromEntries(clients.map(c => [c.id, c.name]));

    const pendingItems = [];
    consignments.forEach(cs => {
      cs.items?.filter(i => i.status === 'pendiente').forEach(item => {
        pendingItems.push({ ...item, clientName: clientMap[cs.clientId] || '—', csId: cs.id, date: cs.createdAt });
      });
    });

    const totalPendingValue = pendingItems.reduce((s, i) => s + i.quantity * i.salePrice, 0);

    const rows = pendingItems.map(i => [
      `<b>#${i.csId}</b>`,
      i.clientName,
      i.productName,
      i.quantity,
      Utils.currency(i.salePrice),
      Utils.currency(i.quantity * i.salePrice),
      Utils.date(i.date),
      Utils.statusBadge(i.status)
    ]);

    return `
      <div class="stats-grid">
        ${statCard('Items pendientes', pendingItems.length, 'en manos de clientes', '🤝')}
        ${statCard('Valor pendiente', Utils.currency(totalPendingValue), 'precio venta', '💰')}
        ${statCard('Clientes activos', new Set(pendingItems.map(i=>i.clientName)).size, 'con consignaciones', '👥')}
      </div>
      <div class="report-section">
        <h3>Productos en manos de clientes</h3>
        ${Utils.table(['Consignación','Cliente','Producto','Cant.','Precio','Valor','Fecha','Estado'], rows, { emptyMsg: 'No hay productos en consignación pendiente' })}
      </div>`;
  };

  // ── Movements Report ─────────────────────────────────────────
  const buildMovementsReport = async () => {
    const movements = await GymDB.getAll('movements');
    movements.sort((a, b) => new Date(b.date) - new Date(a.date));

    const typeLabels = { entry: '📥 Entrada', sale: '🛒 Venta', consignment: '🤝 Consignación', return: '↩ Devolución', adjustment: '🔧 Ajuste' };

    const rows = movements.slice(0, 150).map(m => [
      Utils.datetime(m.date),
      m.productName || '—',
      typeLabels[m.type] || m.type,
      `<span style="color:${m.quantity > 0 ? 'var(--green)' : 'var(--red)'};font-weight:600">${m.quantity > 0 ? '+' : ''}${m.quantity}</span>`,
      m.stockAfter ?? '—',
      m.notes || '—'
    ]);

    return `
      <div class="report-section">
        <h3>Últimos 150 movimientos de inventario</h3>
        ${Utils.table(['Fecha','Producto','Tipo','Cantidad','Stock final','Notas'], rows, { emptyMsg: 'No hay movimientos registrados' })}
      </div>`;
  };

  // ── Helper ───────────────────────────────────────────────────
  const statCard = (title, value, sub, icon) => `
    <div class="stat-card">
      <div class="stat-icon">${icon}</div>
      <div class="stat-body">
        <div class="stat-value">${value}</div>
        <div class="stat-title">${title}</div>
        <div class="stat-sub">${sub}</div>
      </div>
    </div>`;

  window.ReportsModule.statCard = statCard;

  return { render, showTab };
})();
