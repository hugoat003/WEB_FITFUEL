// GymStockPro — Sales Module
window.SalesModule = (() => {

  let cart = [];
  let allProducts = [];

  const render = async () => {
    const sales = await GymDB.getAll('sales');
    sales.sort((a, b) => new Date(b.date) - new Date(a.date));

    const rows = sales.slice(0, 100).map(s => [
      `<b>#${s.id}</b>`,
      Utils.datetime(s.date),
      Utils.statusBadge(s.type),
      s.items?.length || 0,
      Utils.currency(s.total),
      `<div class="action-btns">
        <button class="btn btn-sm btn-ghost" onclick="SalesModule.printSale(${s.id})">🖨 Comprobante</button>
      </div>`
    ]);

    document.getElementById('main-content').innerHTML = `
      <div class="page-header">
        <div>
          <h1>Ventas</h1>
          <p class="page-sub">${sales.length} ventas registradas</p>
        </div>
        <button class="btn btn-primary" onclick="SalesModule.newSale()">+ Nueva Venta</button>
      </div>
      ${Utils.table(['#','Fecha','Tipo','Productos','Total','Acciones'], rows, { emptyMsg: 'No hay ventas registradas' })}
    `;
  };

  const newSale = async () => {
    allProducts = await GymDB.getAll('products');
    cart = [];
    await showSaleModal();
  };

  const showSaleModal = async () => {
    const clients = await GymDB.getAll('clients');
    const body = buildSaleBody(clients);
    const result = await Utils.modal('Nueva Venta', body, { wide: true, confirmLabel: 'Registrar Venta' });
    if (result !== 'confirm') return;
    await processSale();
  };

  const buildSaleBody = (clients) => {
    const productOpts = allProducts
      .filter(p => (p.stock || 0) > 0)
      .map(p => `<option value="${p.id}" data-price="${p.salePrice}" data-wholesale="${p.wholesalePrice||p.salePrice}" data-stock="${p.stock}">${p.name} (Stock: ${p.stock})</option>`)
      .join('');

    const clientOpts = clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    const cartRows = cart.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.price)}</td>
        <td>${Utils.currency(item.quantity * item.price)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="SalesModule.removeCartItem(${i})">✕</button></td>
      </tr>`).join('');

    const total = cart.reduce((s, i) => s + i.quantity * i.price, 0);

    return `
      <div class="form-grid">
        <div class="form-group">
          <label>Tipo de venta</label>
          <select id="sale-type" class="form-input" onchange="SalesModule.updateCartPrices()">
            <option value="retail">Público</option>
            <option value="wholesale">Mayoreo</option>
          </select>
        </div>
        <div class="form-group">
          <label>Cliente (opcional)</label>
          <select id="sale-client" class="form-input">
            <option value="">— Sin cliente —</option>
            ${clientOpts}
          </select>
        </div>
      </div>
      <div class="cart-add-row">
        <select id="sale-product" class="form-input" style="flex:2">${productOpts}</select>
        <input id="sale-qty" type="number" class="form-input" value="1" min="1" style="width:80px">
        <button class="btn btn-accent" onclick="SalesModule.addToCart()">+ Agregar</button>
      </div>
      <div class="cart-table" id="cart-table">
        ${cart.length ? `
          <table class="data-table">
            <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th><th></th></tr></thead>
            <tbody>${cartRows}</tbody>
          </table>
          <div class="cart-total">Total: <b>${Utils.currency(total)}</b></div>
        ` : `<div class="empty-state" style="padding:20px"><span>🛒</span><p>Carrito vacío</p></div>`}
      </div>`;
  };

  window.SalesModule = window.SalesModule || {};

  window.SalesModule.addToCart = async () => {
    const sel = document.getElementById('sale-product');
    const pid = parseInt(sel.value);
    const qty = parseInt(document.getElementById('sale-qty').value) || 1;
    const type = document.getElementById('sale-type').value;
    const opt = sel.options[sel.selectedIndex];
    const stock = parseInt(opt.dataset.stock);
    if (qty > stock) { Utils.toast(`Solo hay ${stock} en stock`, 'error'); return; }
    const price = type === 'wholesale'
      ? parseFloat(opt.dataset.wholesale)
      : parseFloat(opt.dataset.price);
    const existing = cart.find(i => i.productId === pid);
    if (existing) {
      if (existing.quantity + qty > stock) { Utils.toast(`Stock insuficiente`, 'error'); return; }
      existing.quantity += qty;
    } else {
      cart.push({ productId: pid, productName: opt.text.split(' (Stock')[0], quantity: qty, price });
    }
    refreshCart();
  };

  window.SalesModule.removeCartItem = (i) => {
    cart.splice(i, 1);
    refreshCart();
  };

  window.SalesModule.updateCartPrices = () => {
    const type = document.getElementById('sale-type').value;
    cart.forEach(item => {
      const p = allProducts.find(p => p.id === item.productId);
      if (p) item.price = type === 'wholesale' ? (p.wholesalePrice || p.salePrice) : p.salePrice;
    });
    refreshCart();
  };

  const refreshCart = () => {
    const cartRows = cart.map((item, i) => `
      <tr>
        <td>${item.productName}</td>
        <td>${item.quantity}</td>
        <td>${Utils.currency(item.price)}</td>
        <td>${Utils.currency(item.quantity * item.price)}</td>
        <td><button class="btn btn-sm btn-danger-ghost" onclick="SalesModule.removeCartItem(${i})">✕</button></td>
      </tr>`).join('');
    const total = cart.reduce((s, i) => s + i.quantity * i.price, 0);
    const container = document.getElementById('cart-table');
    if (!container) return;
    container.innerHTML = cart.length ? `
      <table class="data-table">
        <thead><tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th><th></th></tr></thead>
        <tbody>${cartRows}</tbody>
      </table>
      <div class="cart-total">Total: <b>${Utils.currency(total)}</b></div>
    ` : `<div class="empty-state" style="padding:20px"><span>🛒</span><p>Carrito vacío</p></div>`;
  };

  const processSale = async () => {
    if (!cart.length) { Utils.toast('El carrito está vacío', 'error'); return; }
    const type = Utils.val('sale-type');
    const clientId = Utils.val('sale-client') ? parseInt(Utils.val('sale-client')) : null;
    const total = cart.reduce((s, i) => s + i.quantity * i.price, 0);
    const now = new Date().toISOString();

    const saleId = await GymDB.add('sales', { type, clientId, items: cart, total, date: now });

    for (const item of cart) {
      await GymDB.updateStock(item.productId, -item.quantity, 'sale', `Venta #${saleId}`);
    }

    const sale = await GymDB.getById('sales', saleId);
    let clientName = '';
    if (clientId) {
      const c = await GymDB.getById('clients', clientId);
      clientName = c?.name || '';
    }

    Utils.toast(`Venta registrada — ${Utils.currency(total)}`);
    Utils.printReceipt(sale, cart, clientName);
    render();
  };

  const printSale = async (id) => {
    const sale = await GymDB.getById('sales', id);
    let clientName = '';
    if (sale.clientId) {
      const c = await GymDB.getById('clients', sale.clientId);
      clientName = c?.name || '';
    }
    Utils.printReceipt(sale, sale.items, clientName);
  };

  return { render, newSale, printSale, addToCart: window.SalesModule.addToCart, removeCartItem: window.SalesModule.removeCartItem, updateCartPrices: window.SalesModule.updateCartPrices };
})();
