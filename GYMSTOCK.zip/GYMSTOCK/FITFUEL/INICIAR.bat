@echo off
title GymStockPro - servidor y tunel
cd /d "%~dp0"

set PY=C:\Users\Admin\AppData\Local\Programs\Python\Python312\python.exe
if not exist "%PY%" set PY=python

"%PY%" iniciar.py
echo.
echo El proceso termino. Presiona una tecla para cerrar.
pause >nul
