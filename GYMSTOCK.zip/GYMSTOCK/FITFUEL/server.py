#!/usr/bin/env python3
"""
GymStockPro / FitFuel — Servidor local con almacenamiento compartido.

Sirve la app estatica y expone una API JSON para que la PC y el celular
compartan LA MISMA base de datos (antes vivia solo dentro del navegador).

  python server.py                 arranca en http://localhost:3000
  python server.py --set-pin 1234  define el PIN de acceso remoto
  python server.py --port 3000     cambia el puerto

Los datos se guardan en  data/gymstock.json  con escritura atomica y
respaldos automaticos en  data/backups/ . Nada se borra nunca.
"""

import argparse
import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import shutil
import sys
import threading
import time
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))

# Se reajustan en main() si se pasa --data-dir (util para probar sin tocar
# los datos reales).
DATA_DIR = os.path.join(ROOT, "data")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
DATA_FILE = os.path.join(DATA_DIR, "gymstock.json")
CONFIG_FILE = os.path.join(DATA_DIR, "config.json")


def set_data_dir(path):
    global DATA_DIR, BACKUP_DIR, DATA_FILE, CONFIG_FILE
    DATA_DIR = os.path.abspath(path)
    BACKUP_DIR = os.path.join(DATA_DIR, "backups")
    DATA_FILE = os.path.join(DATA_DIR, "gymstock.json")
    CONFIG_FILE = os.path.join(DATA_DIR, "config.json")

# Los mismos object stores que usaba IndexedDB.
STORES = [
    "products", "movements", "sales", "consignments",
    "clients", "suppliers", "purchases", "settings", "cashflows",
]
# 'settings' se indexa por 'key' (string); el resto por 'id' autoincremental.
KEY_FIELD = {s: ("key" if s == "settings" else "id") for s in STORES}
AUTO_ID = {s for s in STORES if s != "settings"}

BACKUP_MIN_INTERVAL = 300     # seg. entre respaldos rotativos
BACKUP_KEEP = 60              # cuantos respaldos conservar
SESSION_TTL = 30 * 24 * 3600  # 30 dias
MAX_PIN_FAILS = 8
PIN_FAIL_WINDOW = 900         # 15 min

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


# ──────────────────────────────────────────────────────────────────
#  Almacen de datos (thread-safe, escritura atomica, con respaldos)
# ──────────────────────────────────────────────────────────────────
class Store:
    def __init__(self):
        self._lock = threading.RLock()
        self._last_backup = 0.0
        os.makedirs(DATA_DIR, exist_ok=True)
        os.makedirs(BACKUP_DIR, exist_ok=True)
        self.state = self._load()

    # -- persistencia ------------------------------------------------
    def _empty(self):
        return {
            "rev": 0,
            "createdAt": now_iso(),
            "updatedAt": now_iso(),
            "counters": {s: 0 for s in AUTO_ID},
            "stores": {s: {} for s in STORES},
        }

    def _load(self):
        if not os.path.exists(DATA_FILE):
            return self._empty()
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception as exc:
            # Nunca sobrescribimos datos que no pudimos leer: los apartamos.
            broken = os.path.join(
                BACKUP_DIR, "ILEGIBLE-%s.json" % time.strftime("%Y%m%d-%H%M%S"))
            try:
                shutil.copy2(DATA_FILE, broken)
            except Exception:
                pass
            print("  !! No se pudo leer %s (%s)." % (DATA_FILE, exc))
            print("  !! Copia del archivo dañado en %s" % broken)
            raise SystemExit(
                "Arranque abortado para no perder informacion. "
                "Revisa el archivo antes de continuar.")
        # Completa stores/contadores que pudieran faltar (versiones viejas).
        data.setdefault("rev", 0)
        data.setdefault("counters", {})
        data.setdefault("stores", {})
        for s in STORES:
            data["stores"].setdefault(s, {})
            if s in AUTO_ID:
                data["counters"].setdefault(s, 0)
        return data

    def _backup_locked(self):
        """Respaldo rotativo, como mucho uno cada BACKUP_MIN_INTERVAL."""
        if not os.path.exists(DATA_FILE):
            return
        if time.time() - self._last_backup < BACKUP_MIN_INTERVAL:
            return
        stamp = time.strftime("%Y%m%d-%H%M%S")
        try:
            shutil.copy2(DATA_FILE, os.path.join(BACKUP_DIR, "gymstock-%s.json" % stamp))
            self._last_backup = time.time()
        except Exception as exc:
            print("  aviso: no se pudo respaldar (%s)" % exc)
            return
        try:
            files = sorted(f for f in os.listdir(BACKUP_DIR)
                           if f.startswith("gymstock-") and f.endswith(".json"))
            for old in files[:-BACKUP_KEEP]:
                os.remove(os.path.join(BACKUP_DIR, old))
        except Exception:
            pass

    def _save_locked(self):
        self._backup_locked()
        self.state["updatedAt"] = now_iso()
        tmp = DATA_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.state, fh, ensure_ascii=False, separators=(",", ":"))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, DATA_FILE)   # atomico: nunca queda a medias

    # -- lectura -----------------------------------------------------
    def snapshot(self):
        with self._lock:
            return {
                "rev": self.state["rev"],
                "stores": {s: list(self.state["stores"][s].values()) for s in STORES},
            }

    def rev(self):
        with self._lock:
            return self.state["rev"]

    def total_records(self):
        with self._lock:
            return sum(len(self.state["stores"][s]) for s in STORES if s != "settings")

    # -- escritura ---------------------------------------------------
    def mutate(self, ops):
        """Aplica una lista de operaciones de forma atomica. Devuelve ids."""
        with self._lock:
            results = []
            for op in ops:
                action = op.get("op")

                # Movimiento de inventario resuelto en el servidor: leer el
                # stock y escribirlo aqui evita que dos dispositivos vendiendo
                # a la vez se pisen y dejen el inventario descuadrado.
                if action == "updateStock":
                    results.append(self._update_stock_locked(op))
                    continue

                store = op.get("store")
                if store not in STORES:
                    raise ValueError("store desconocido: %r" % store)
                bucket = self.state["stores"][store]
                kf = KEY_FIELD[store]

                if action in ("add", "put"):
                    value = op.get("value")
                    if not isinstance(value, dict):
                        raise ValueError("value debe ser objeto")
                    key = value.get(kf)
                    if key is None:
                        if store not in AUTO_ID:
                            raise ValueError("falta '%s' en %s" % (kf, store))
                        self.state["counters"][store] += 1
                        key = self.state["counters"][store]
                        value[kf] = key
                    elif store in AUTO_ID and isinstance(key, int) \
                            and key > self.state["counters"][store]:
                        # Mantiene el contador por delante de ids importados.
                        self.state["counters"][store] = key
                    bucket[str(key)] = value
                    results.append(key)

                elif action == "delete":
                    key = op.get("id")
                    bucket.pop(str(key), None)
                    results.append(key)

                else:
                    raise ValueError("op desconocida: %r" % action)

            self.state["rev"] += 1
            self._save_locked()
            return {"rev": self.state["rev"], "results": results}

    def _update_stock_locked(self, op):
        """Equivalente atomico del viejo GymDB.updateStock del navegador."""
        pid = op.get("productId")
        products = self.state["stores"]["products"]
        product = products.get(str(pid))
        if product is None:
            raise ValueError("Producto no encontrado (id %s)" % pid)

        delta = op.get("delta") or 0
        product["stock"] = (product.get("stock") or 0) + delta
        product["updatedAt"] = now_iso()
        products[str(pid)] = product

        self.state["counters"]["movements"] += 1
        mid = self.state["counters"]["movements"]
        movement = {
            "id": mid,
            "productId": pid,
            "productName": product.get("name"),
            "type": op.get("movementType"),
            "quantity": delta,
            "stockAfter": product["stock"],
            "notes": op.get("notes") or "",
            "date": now_iso(),
        }
        self.state["stores"]["movements"][str(mid)] = movement
        return {"product": product, "movement": movement}

    def seed(self, stores):
        """Carga inicial desde el IndexedDB del navegador. Solo si esta vacio."""
        with self._lock:
            if self.total_records() > 0:
                return {"seeded": False, "reason": "El servidor ya tiene datos."}
            counts = {}
            for s in STORES:
                items = stores.get(s) or []
                kf = KEY_FIELD[s]
                bucket = self.state["stores"][s]
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    key = item.get(kf)
                    if key is None:
                        if s not in AUTO_ID:
                            continue
                        self.state["counters"][s] += 1
                        key = self.state["counters"][s]
                        item[kf] = key
                    if s in AUTO_ID and isinstance(key, int) and key > self.state["counters"][s]:
                        self.state["counters"][s] = key
                    bucket[str(key)] = item
                counts[s] = len(bucket)
            self.state["rev"] += 1
            self.state["seededAt"] = now_iso()
            self._save_locked()
            return {"seeded": True, "counts": counts, "rev": self.state["rev"]}


# ──────────────────────────────────────────────────────────────────
#  Configuracion: PIN y sesiones
# ──────────────────────────────────────────────────────────────────
class Config:
    def __init__(self):
        self._lock = threading.RLock()
        os.makedirs(DATA_DIR, exist_ok=True)
        self.cfg = self._load()
        self._fails = {}

    def _load(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
                    cfg = json.load(fh)
            except Exception:
                cfg = {}
        else:
            cfg = {}
        cfg.setdefault("pin", None)      # {"salt":..., "hash":...}
        cfg.setdefault("sessions", {})   # token -> expiry (epoch)
        return cfg

    def _save_locked(self):
        tmp = CONFIG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.cfg, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_FILE)

    # -- PIN ---------------------------------------------------------
    @staticmethod
    def _hash(pin, salt):
        return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 120_000).hex()

    def has_pin(self):
        with self._lock:
            return bool(self.cfg.get("pin"))

    def set_pin(self, pin):
        pin = str(pin).strip()
        if len(pin) < 4:
            raise ValueError("El PIN debe tener al menos 4 caracteres.")
        with self._lock:
            salt = secrets.token_hex(16)
            self.cfg["pin"] = {"salt": salt, "hash": self._hash(pin, salt)}
            self.cfg["sessions"] = {}    # invalida sesiones anteriores
            self._save_locked()

    def check_pin(self, pin):
        with self._lock:
            rec = self.cfg.get("pin")
            if not rec:
                return False
            return hmac.compare_digest(self._hash(str(pin), rec["salt"]), rec["hash"])

    # -- limitador de intentos --------------------------------------
    def too_many_fails(self, ip):
        with self._lock:
            hits = [t for t in self._fails.get(ip, []) if time.time() - t < PIN_FAIL_WINDOW]
            self._fails[ip] = hits
            return len(hits) >= MAX_PIN_FAILS

    def record_fail(self, ip):
        with self._lock:
            self._fails.setdefault(ip, []).append(time.time())

    # -- sesiones ----------------------------------------------------
    def new_session(self):
        with self._lock:
            token = secrets.token_urlsafe(32)
            self.cfg["sessions"][token] = time.time() + SESSION_TTL
            # limpia expiradas
            self.cfg["sessions"] = {
                t: e for t, e in self.cfg["sessions"].items() if e > time.time()}
            self._save_locked()
            return token

    def valid_session(self, token):
        if not token:
            return False
        with self._lock:
            exp = self.cfg["sessions"].get(token)
            return bool(exp and exp > time.time())

    def drop_session(self, token):
        with self._lock:
            if token in self.cfg["sessions"]:
                del self.cfg["sessions"][token]
                self._save_locked()


STORE = None
CONFIG = None


# ──────────────────────────────────────────────────────────────────
#  HTTP
# ──────────────────────────────────────────────────────────────────
class Handler(BaseHTTPRequestHandler):
    server_version = "GymStockPro"
    protocol_version = "HTTP/1.1"

    # -- utilidades --------------------------------------------------
    def log_message(self, fmt, *args):
        if "--verbose" in sys.argv:
            super().log_message(fmt, *args)

    def _is_remote(self):
        """True si la peticion llega por el tunel de Cloudflare.

        cloudflared siempre agrega estas cabeceras; un visitante remoto no
        puede quitarlas. Una peticion directa desde esta PC no las trae.
        """
        return bool(self.headers.get("CF-Connecting-IP")
                    or self.headers.get("X-Forwarded-For"))

    def _client_ip(self):
        return (self.headers.get("CF-Connecting-IP")
                or self.headers.get("X-Forwarded-For", "").split(",")[0].strip()
                or self.client_address[0])

    def _cookie(self, name):
        raw = self.headers.get("Cookie", "")
        for part in raw.split(";"):
            if "=" in part:
                k, v = part.split("=", 1)
                if k.strip() == name:
                    return unquote(v.strip())
        return None

    def _authorized(self):
        if not self._is_remote():
            return True                      # esta PC: acceso directo
        if not CONFIG.has_pin():
            return False                     # sin PIN definido, nada remoto
        return CONFIG.valid_session(self._cookie("gsp_session"))

    def _send_json(self, obj, status=200, cookie=None):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        if length > 64 * 1024 * 1024:
            raise ValueError("cuerpo demasiado grande")
        return json.loads(self.rfile.read(length).decode("utf-8"))

    # -- ruteo -------------------------------------------------------
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/"):
            return self._api_get(path, parse_qs(parsed.query))
        return self._serve_static(path)

    def do_POST(self):
        path = urlparse(self.path).path
        if not path.startswith("/api/"):
            return self._send_json({"error": "no encontrado"}, 404)
        try:
            payload = self._read_json()
        except Exception as exc:
            return self._send_json({"error": "JSON invalido: %s" % exc}, 400)
        return self._api_post(path, payload)

    # -- API GET -----------------------------------------------------
    def _api_get(self, path, query):
        if path == "/api/session":
            return self._send_json({
                "authorized": self._authorized(),
                "remote": self._is_remote(),
                "pinConfigured": CONFIG.has_pin(),
                "hasData": STORE.total_records() > 0,
                "rev": STORE.rev(),
            })

        if not self._authorized():
            return self._send_json({"error": "PIN requerido", "needsPin": True}, 401)

        if path == "/api/state":
            return self._send_json(STORE.snapshot())

        if path == "/api/rev":
            return self._send_json({"rev": STORE.rev()})

        return self._send_json({"error": "no encontrado"}, 404)

    # -- API POST ----------------------------------------------------
    def _api_post(self, path, payload):
        if path == "/api/login":
            ip = self._client_ip()
            if CONFIG.too_many_fails(ip):
                return self._send_json(
                    {"error": "Demasiados intentos. Espera 15 minutos."}, 429)
            if not CONFIG.has_pin():
                return self._send_json({"error": "No hay PIN configurado."}, 400)
            if not CONFIG.check_pin(payload.get("pin", "")):
                CONFIG.record_fail(ip)
                return self._send_json({"error": "PIN incorrecto"}, 401)
            token = CONFIG.new_session()
            flags = "Path=/; HttpOnly; SameSite=Lax; Max-Age=%d" % SESSION_TTL
            if self._is_remote():
                flags += "; Secure"
            return self._send_json({"ok": True},
                                   cookie="gsp_session=%s; %s" % (token, flags))

        if path == "/api/logout":
            CONFIG.drop_session(self._cookie("gsp_session"))
            return self._send_json({"ok": True},
                                   cookie="gsp_session=; Path=/; Max-Age=0")

        if path == "/api/set-pin":
            # Solo desde esta PC: impide que alguien remoto se apodere de la app.
            if self._is_remote():
                return self._send_json(
                    {"error": "El PIN solo se puede cambiar desde la computadora."}, 403)
            try:
                CONFIG.set_pin(payload.get("pin", ""))
            except ValueError as exc:
                return self._send_json({"error": str(exc)}, 400)
            return self._send_json({"ok": True})

        if not self._authorized():
            return self._send_json({"error": "PIN requerido", "needsPin": True}, 401)

        if path == "/api/mutate":
            ops = payload.get("ops")
            if not isinstance(ops, list) or not ops:
                return self._send_json({"error": "ops vacio"}, 400)
            try:
                return self._send_json(STORE.mutate(ops))
            except ValueError as exc:
                return self._send_json({"error": str(exc)}, 400)
            except Exception as exc:
                return self._send_json({"error": "error al guardar: %s" % exc}, 500)

        if path == "/api/seed":
            stores = payload.get("stores")
            if not isinstance(stores, dict):
                return self._send_json({"error": "falta 'stores'"}, 400)
            try:
                result = STORE.seed(stores)
            except Exception as exc:
                return self._send_json({"error": "error al migrar: %s" % exc}, 500)
            if result.get("seeded"):
                total = sum(v for k, v in result["counts"].items() if k != "settings")
                print("  >> Migracion completada: %d registros importados "
                      "desde el navegador." % total)
            return self._send_json(result)

        return self._send_json({"error": "no encontrado"}, 404)

    # -- estaticos ---------------------------------------------------
    def _serve_static(self, url_path):
        rel = unquote(url_path.lstrip("/")) or "index.html"
        full = os.path.normpath(os.path.join(ROOT, rel))
        if not full.startswith(ROOT + os.sep) and full != ROOT:
            return self._send_text("Prohibido", 403)
        # Los datos y respaldos nunca se sirven por HTTP.
        if full.startswith(DATA_DIR):
            return self._send_text("Prohibido", 403)

        if not os.path.isfile(full):
            full = os.path.join(ROOT, "index.html")   # fallback SPA
            if not os.path.isfile(full):
                return self._send_text("No encontrado", 404)

        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext) or mimetypes.guess_type(full)[0] or "application/octet-stream"
        try:
            with open(full, "rb") as fh:
                body = fh.read()
        except OSError:
            return self._send_text("Error de lectura", 500)

        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        # Sin cache: asi el celular siempre recibe la version actual.
        self.send_header("Cache-Control", "no-cache, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, msg, status):
        body = msg.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ──────────────────────────────────────────────────────────────────
def main():
    global STORE, CONFIG

    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--port", type=int, default=3000)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--set-pin", dest="set_pin", default=None,
                    help="define el PIN de acceso remoto y termina")
    ap.add_argument("--data-dir", dest="data_dir", default=None,
                    help="carpeta de datos alterna (para pruebas)")
    ap.add_argument("--verbose", action="store_true")
    args, _ = ap.parse_known_args()

    if args.data_dir:
        set_data_dir(args.data_dir)

    CONFIG = Config()

    if args.set_pin is not None:
        try:
            CONFIG.set_pin(args.set_pin)
        except ValueError as exc:
            raise SystemExit("Error: %s" % exc)
        print("PIN actualizado. Las sesiones anteriores se cerraron.")
        return

    STORE = Store()

    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    srv.daemon_threads = True

    total = STORE.total_records()
    print("=" * 58)
    print(" GymStockPro  ->  http://localhost:%d" % args.port)
    print(" Datos:    %s" % DATA_FILE)
    print(" Respaldos:%s" % BACKUP_DIR)
    print(" Registros en el servidor: %d" % total)
    if total == 0:
        print("   (vacio: al abrir la app en esta PC se migrara")
        print("    automaticamente lo que ya tienes en el navegador)")
    print(" PIN remoto: %s" % ("configurado" if CONFIG.has_pin()
                               else "SIN CONFIGURAR - el acceso por tunel esta bloqueado"))
    print("=" * 58)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")


if __name__ == "__main__":
    main()
