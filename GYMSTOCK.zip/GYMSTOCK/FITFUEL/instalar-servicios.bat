@echo off
setlocal
title GymStockPro - instalar arranque automatico

REM ===================================================================
REM  Deja el servidor y el tunel arrancando SOLOS al encender la PC,
REM  sin que nadie tenga que iniciar sesion en Windows.
REM
REM    - Servicio "cloudflared"    -> publica https://app.fitfuelgt.com
REM    - Tarea   "GymStockServidor" -> mantiene server.py en el puerto 3000
REM
REM  Se ejecuta UNA SOLA VEZ, como administrador. Para deshacerlo:
REM  desinstalar-servicios.bat
REM ===================================================================

cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo   Esto necesita permisos de administrador.
  echo   Cierra esta ventana, haz CLIC DERECHO sobre instalar-servicios.bat
  echo   y elige "Ejecutar como administrador".
  echo.
  pause
  exit /b 1
)

set CFDIR=C:\Users\Admin\.cloudflared
set SYSDIR=C:\Windows\System32\config\systemprofile\.cloudflared
set CFEXE=%~dp0bin\cloudflared.exe

echo.
echo [1/6] Retirando el arranque viejo (tarea GymStockTunel)...
schtasks /delete /tn "GymStockTunel" /f >nul 2>&1
if errorlevel 1 (echo       no existia, nada que retirar) else (echo       retirada)

echo.
echo [2/6] Deteniendo el tunel rapido y el servidor actuales...
taskkill /f /im cloudflared.exe >nul 2>&1
REM Solo el proceso duenno del puerto 3000: matar todos los python.exe se
REM llevaria por delante cosas que no son nuestras.
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":3000" ^| findstr LISTENING') do taskkill /f /pid %%p >nul 2>&1
echo       detenidos

echo.
echo [3/6] Copiando credenciales al perfil del sistema...
REM El servicio corre como SYSTEM y busca su configuracion aqui, no en
REM la carpeta personal de Admin.
if not exist "%SYSDIR%" mkdir "%SYSDIR%"
copy /y "%CFDIR%\cert.pem" "%SYSDIR%\" >nul
copy /y "%CFDIR%\config.yml" "%SYSDIR%\" >nul
copy /y "%CFDIR%\*.json" "%SYSDIR%\" >nul
echo       copiadas a %SYSDIR%

echo.
echo [4/6] Instalando el servicio cloudflared...
"%CFEXE%" service install
if errorlevel 1 (
  echo.
  echo   *** Fallo la instalacion del servicio. Nada mas se ha cambiado.
  echo.
  pause
  exit /b 1
)
REM Que Windows lo vuelva a levantar solo si se cae, con esperas crecientes.
sc failure cloudflared reset= 86400 actions= restart/5000/restart/15000/restart/60000 >nul
sc start cloudflared >nul 2>&1
echo       servicio instalado y arrancado

echo.
echo [5/6] Creando la tarea del servidor (al encender la maquina)...
schtasks /create /tn "GymStockServidor" /tr "%~dp0servidor-persistente.bat" /sc ONSTART /ru SYSTEM /rl HIGHEST /f >nul
if errorlevel 1 (
  echo   *** No se pudo crear la tarea.
  pause
  exit /b 1
)
schtasks /run /tn "GymStockServidor" >nul 2>&1
echo       tarea creada y arrancada

echo.
echo [6/6] Comprobando...
ping -n 16 127.0.0.1 >nul
sc query cloudflared | findstr /i "STATE"
netstat -ano | findstr ":3000" | findstr LISTENING >nul && (echo       servidor escuchando en el puerto 3000) || (echo       OJO: nada escucha en el 3000 todavia, mira data\servidor.log)

echo.
echo ===================================================================
echo   Listo. Prueba en el celular:  https://app.fitfuelgt.com
echo   Esa direccion ya no cambia nunca, ni aunque reinicies.
echo ===================================================================
echo.
pause
